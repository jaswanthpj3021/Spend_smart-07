
import React from 'react';
import { User } from '../types';

interface SidebarProps {
  currentView: string;
  setView: (view: any) => void;
  user: User;
  onLogout: () => void;
}

const Sidebar: React.FC<SidebarProps> = ({ currentView, setView, user, onLogout }) => {
  const menuItems = [
    { id: 'dashboard', label: 'Dashboard', icon: 'fa-table-columns' },
    { id: 'transactions', label: 'Expenses', icon: 'fa-indian-rupee-sign' },
    { id: 'budget', label: 'Budget Plan', icon: 'fa-vault' },
    { id: 'friends', label: 'Friends', icon: 'fa-user-group' },
    { id: 'notes', label: 'Receipt Notes', icon: 'fa-sticky-note' },
    { id: 'chat', label: 'Community Chat', icon: 'fa-comments' },
    { id: 'profile', label: 'Account', icon: 'fa-circle-user' },
  ];

  return (
    <aside className="w-64 glass border-r border-slate-800 hidden md:flex flex-col">
      <div className="p-6">
        <div className="flex items-center space-x-3 mb-8">
          <div className="w-10 h-10 bg-emerald-600 rounded-xl flex items-center justify-center shadow-lg shadow-emerald-500/30">
            <i className="fas fa-indian-rupee-sign text-white text-xl"></i>
          </div>
          <span className="text-2xl font-black tracking-tight text-white uppercase italic">Kuber</span>
        </div>

        <nav className="space-y-1">
          {menuItems.map((item) => (
            <button
              key={item.id}
              onClick={() => setView(item.id)}
              className={`w-full flex items-center space-x-3 px-4 py-3 rounded-xl transition-all duration-200 ${
                currentView === item.id 
                  ? 'bg-emerald-600/10 text-emerald-400 border border-emerald-500/20' 
                  : 'text-slate-400 hover:text-white hover:bg-slate-800/50'
              }`}
            >
              <i className={`fas ${item.icon} w-5`}></i>
              <span className="font-bold text-xs uppercase tracking-widest">{item.label}</span>
            </button>
          ))}
        </nav>
      </div>

      <div className="mt-auto p-6 border-t border-slate-800">
        <div className="flex items-center space-x-3 mb-4">
          {user.avatar ? (
            <img 
              src={user.avatar} 
              alt="Avatar" 
              className="w-10 h-10 rounded-full border-2 border-emerald-900/50 object-cover"
            />
          ) : (
            <div className="w-10 h-10 rounded-full bg-emerald-600 flex items-center justify-center border-2 border-emerald-500/50 shadow-lg">
              <i className="fas fa-user text-white text-sm"></i>
            </div>
          )}
          <div className="truncate">
            <p className="text-sm font-semibold text-white truncate">{user.name}</p>
            <div className="flex items-center space-x-1">
              <div className="w-1 h-1 bg-emerald-500 rounded-full animate-pulse"></div>
              <p className="text-[9px] text-slate-500 truncate uppercase font-black">Authorized</p>
            </div>
          </div>
        </div>
        <button 
          onClick={onLogout}
          className="w-full flex items-center justify-center space-x-2 px-4 py-2 bg-slate-800 hover:bg-red-900/20 hover:text-red-400 text-slate-400 rounded-lg transition-colors border border-slate-700"
        >
          <i className="fas fa-power-off text-xs"></i>
          <span className="text-[10px] font-black uppercase tracking-widest">Logout</span>
        </button>
      </div>
    </aside>
  );
};

export default Sidebar;
