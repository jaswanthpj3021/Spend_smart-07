
import { GoogleGenAI } from "@google/genai";
import { Transaction } from "../types";

// Note: Always use process.env.API_KEY directly in New GoogleGenAI({ apiKey: ... })

export const getFinancialAdvice = async (transactions: Transaction[], userBudget: number) => {
  // Always initialize right before making an API call
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  try {
    const summary = transactions.reduce((acc: any, t) => {
      acc[t.category] = (acc[t.category] || 0) + t.amount;
      return acc;
    }, {});

    const prompt = `
      As a financial advisor, analyze this spending data:
      Total Budget: $${userBudget}
      Spending Summary: ${JSON.stringify(summary)}
      
      Please provide 3 actionable, concise pieces of advice to save money based on these categories.
      Keep it professional and encouraging.
    `;

    const response = await ai.models.generateContent({
      model: 'gemini-3-pro-preview', // High-reasoning task: 'gemini-3-pro-preview'
      contents: prompt,
    });

    return response.text;
  } catch (error) {
    console.error("Gemini Error:", error);
    return "Keep tracking your expenses to get personalized AI advice!";
  }
};

export const chatWithAI = async (message: string, history: any[] = []) => {
  // Always initialize right before making an API call
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  try {
    const chat = ai.chats.create({
      model: 'gemini-3-flash-preview', // Basic Text/Chat: 'gemini-3-flash-preview'
      history: history,
      config: {
        systemInstruction: "You are SmartSpend AI, a helpful and witty financial companion. Help users with budgeting, saving tips, and general financial education.",
      }
    });

    // Correctly using chat.sendMessage for active chat sessions
    const response = await chat.sendMessage({ message });

    return response.text;
  } catch (error) {
    console.error("Chat Error:", error);
    return "I'm having a bit of trouble thinking right now. Could you repeat that?";
  }
};
