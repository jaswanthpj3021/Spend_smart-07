
import React, { useState, useRef, useEffect } from 'react';
import { User, ChatMessage, Friend } from '../types';
import { chatWithAI } from '../services/geminiService';

const Chat: React.FC<{ user: User }> = ({ user }) => {
  const [activeTab, setActiveTab] = useState<'ai' | 'community'>('ai');
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);
  
  const [friends] = useState<Friend[]>(() => {
    const saved = localStorage.getItem('smartspend_friends');
    return saved ? JSON.parse(saved) : [];
  });

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isTyping]);

  const handleSend = async () => {
    if (!input.trim()) return;

    const userMsg: ChatMessage = {
      id: Date.now().toString(),
      sender: 'user',
      text: input,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setMessages([...messages, userMsg]);
    setInput('');

    if (activeTab === 'ai') {
      setIsTyping(true);
      const aiResponse = await chatWithAI(input, []);
      const aiMsg: ChatMessage = {
        id: (Date.now() + 1).toString(),
        sender: 'ai',
        text: aiResponse || "I didn't quite catch that.",
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };
      setMessages(prev => [...prev, aiMsg]);
      setIsTyping(false);
    } else {
      setTimeout(() => {
        // Use real friends if available, otherwise fallback to SmartBot
        const speaker = friends.length > 0 ? friends[Math.floor(Math.random() * friends.length)] : { name: 'SmartBot' };
        const communityMsg: ChatMessage = {
          id: (Date.now() + 1).toString(),
          sender: 'community',
          name: speaker.name,
          text: friends.length > 0 
            ? `I totally agree with you, ${user.name.split(' ')[0]}! Checking my daily budget has been a game changer.`
            : "Welcome to the community! Add friends to see their activity here.",
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
        };
        setMessages(prev => [...prev, communityMsg]);
      }, 1000);
    }
  };

  return (
    <div className="flex flex-col h-[calc(100vh-140px)] glass rounded-3xl overflow-hidden border border-slate-800">
      <div className="p-4 border-b border-slate-800 flex items-center justify-between bg-slate-900/50">
        <div className="flex space-x-2">
          <button 
            onClick={() => { setActiveTab('ai'); setMessages([]); }}
            className={`px-4 py-2 rounded-xl text-sm font-bold transition-all ${activeTab === 'ai' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:bg-slate-800'}`}
          >
            AI Assistant
          </button>
          <button 
            onClick={() => { setActiveTab('community'); setMessages([]); }}
            className={`px-4 py-2 rounded-xl text-sm font-bold transition-all ${activeTab === 'community' ? 'bg-emerald-600 text-white' : 'text-slate-400 hover:bg-slate-800'}`}
          >
            Community
          </button>
        </div>
        <div className="flex items-center space-x-2">
          <div className={`w-2 h-2 rounded-full ${activeTab === 'ai' ? 'bg-indigo-500 animate-pulse' : 'bg-emerald-500 animate-pulse'}`}></div>
          <span className="text-xs text-slate-500 font-medium">
            {activeTab === 'ai' ? 'AI Online' : `${friends.length} Network Contacts Active`}
          </span>
        </div>
      </div>

      <div ref={scrollRef} className="flex-1 overflow-y-auto p-6 space-y-6">
        {messages.length === 0 && (
          <div className="h-full flex flex-col items-center justify-center text-center px-10">
            <div className={`w-16 h-16 rounded-3xl flex items-center justify-center mb-4 ${activeTab === 'ai' ? 'bg-indigo-600/20 text-indigo-400' : 'bg-emerald-600/20 text-emerald-400'}`}>
              <i className={`fas ${activeTab === 'ai' ? 'fa-robot' : 'fa-users'} text-3xl`}></i>
            </div>
            <h3 className="text-xl font-bold text-white mb-2">
              {activeTab === 'ai' ? 'Ask SmartSpend AI' : 'Community Hub'}
            </h3>
            <div className="flex -space-x-2 mb-4">
              {friends.slice(0, 5).map(f => (
                <img key={f.id} src={f.avatar} className="w-8 h-8 rounded-full border-2 border-slate-950" title={f.name} />
              ))}
              {friends.length > 5 && (
                <div className="w-8 h-8 rounded-full bg-slate-800 flex items-center justify-center text-[10px] font-bold border-2 border-slate-950">+{friends.length - 5}</div>
              )}
            </div>
            <p className="text-slate-400 text-sm max-w-xs">
              {activeTab === 'ai' 
                ? "Analyze your trends or ask for saving strategies."
                : friends.length > 0 
                  ? `Collaborate with ${friends.length} active members from your network.`
                  : "Your network is quiet. Invite friends to see them active in the community!"}
            </p>
          </div>
        )}

        {messages.map((m) => (
          <div key={m.id} className={`flex ${m.sender === 'user' ? 'justify-end' : 'justify-start'}`}>
            <div className={`max-w-[80%] rounded-2xl p-4 ${
              m.sender === 'user' 
                ? 'bg-indigo-600 text-white rounded-tr-none' 
                : 'bg-slate-800 text-slate-100 rounded-tl-none border border-white/5'
            }`}>
              {(m.sender === 'community' && m.name) && (
                <p className="text-[10px] font-bold text-emerald-400 uppercase mb-1">{m.name}</p>
              )}
              <p className="text-sm leading-relaxed">{m.text}</p>
              <p className={`text-[10px] mt-2 opacity-50 ${m.sender === 'user' ? 'text-white' : 'text-slate-400'}`}>
                {m.timestamp}
              </p>
            </div>
          </div>
        ))}
        {isTyping && (
          <div className="flex justify-start">
            <div className="bg-slate-800 rounded-2xl p-4 rounded-tl-none flex space-x-1">
              <div className="w-1.5 h-1.5 bg-indigo-400 rounded-full animate-bounce"></div>
              <div className="w-1.5 h-1.5 bg-indigo-400 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
              <div className="w-1.5 h-1.5 bg-indigo-400 rounded-full animate-bounce" style={{ animationDelay: '0.4s' }}></div>
            </div>
          </div>
        )}
      </div>

      <div className="p-4 bg-slate-900/80 border-t border-slate-800">
        <div className="flex items-center space-x-3">
          <input 
            type="text" 
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSend()}
            placeholder={activeTab === 'ai' ? "Ask AI for advice..." : "Chat with your network..."}
            className="flex-1 bg-slate-800 border border-slate-700 rounded-xl px-4 py-3 text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
          />
          <button 
            onClick={handleSend}
            disabled={!input.trim()}
            className="w-12 h-12 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 disabled:bg-slate-700 rounded-xl flex items-center justify-center text-white transition-all shadow-lg"
          >
            <i className="fas fa-paper-plane"></i>
          </button>
        </div>
      </div>
    </div>
  );
};

export default Chat;
