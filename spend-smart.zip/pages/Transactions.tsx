
import React, { useState, useEffect } from 'react';
import { User, Transaction, Category } from '../types';

const CATEGORIES: Category[] = ['Food', 'Transport', 'Shopping', 'Rent', 'Entertainment', 'Other'];

const Transactions: React.FC<{ user: User }> = ({ user }) => {
  const [transactions, setTransactions] = useState<Transaction[]>(() => {
    const saved = localStorage.getItem('smartspend_transactions');
    return saved ? JSON.parse(saved) : [];
  });
  const [showAdd, setShowAdd] = useState(false);
  const [showShareMenu, setShowShareMenu] = useState(false);
  const [filter, setFilter] = useState<string>('all');
  
  const [newTx, setNewTx] = useState({
    amount: '',
    description: '',
    category: 'Food' as Category,
    type: 'expense' as 'expense' | 'income',
    date: new Date().toISOString().split('T')[0],
    note: '',
    image: null as string | null
  });

  useEffect(() => {
    localStorage.setItem('smartspend_transactions', JSON.stringify(transactions));
  }, [transactions]);

  const addTransaction = (e: React.FormEvent) => {
    e.preventDefault();
    const tx: Transaction = {
      id: Math.random().toString(36).substr(2, 9),
      userId: user.id,
      amount: parseFloat(newTx.amount),
      description: newTx.description,
      category: newTx.category,
      type: newTx.type,
      date: newTx.date,
      note: newTx.note,
      imageUrl: newTx.image || undefined
    };
    setTransactions([tx, ...transactions]);
    setShowAdd(false);
    setNewTx({
      amount: '',
      description: '',
      category: 'Food' as Category,
      type: 'expense' as 'expense' | 'income',
      date: new Date().toISOString().split('T')[0],
      note: '',
      image: null
    });
  };

  const deleteTx = (id: string) => {
    setTransactions(transactions.filter(t => t.id !== id));
  };

  const filteredTx = transactions.filter(t => {
    if (filter === 'all') return true;
    return t.type === filter;
  });

  const getSummaryData = () => {
    const total = filteredTx.reduce((sum, t) => sum + t.amount, 0);
    return {
      total,
      count: filteredTx.length,
      filter: filter.toUpperCase(),
      text: `📊 *Spend Smart Audit Report*\n\n👤 *User:* ${user.name}\n📂 *Filter:* ${filter.toUpperCase()}\n📑 *Records:* ${filteredTx.length}\n💰 *Total Value:* ₹${total.toLocaleString()}\n\nTracked securely in my private vault. 🚀`
    };
  };

  const generateCSV = () => {
    const headers = ["Date", "Description", "Category", "Amount", "Type", "Note"];
    const csvRows = filteredTx.map(t => [
      t.date,
      `"${t.description.replace(/"/g, '""')}"`,
      t.category,
      t.amount,
      t.type,
      `"${(t.note || '').replace(/"/g, '""')}"`
    ].join(','));

    return [headers.join(','), ...csvRows].join('\n');
  };

  const handleExportCSV = () => {
    if (filteredTx.length === 0) {
      alert("No data available in current view to export.");
      return;
    }
    const csvContent = generateCSV();
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.setAttribute("href", url);
    link.setAttribute("download", `spend_smart_${filter}_audit.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const shareToWhatsApp = () => {
    const { text } = getSummaryData();
    window.open(`https://wa.me/?text=${encodeURIComponent(text)}`, '_blank');
    setShowShareMenu(false);
  };

  const shareToInstagram = () => {
    const { text } = getSummaryData();
    navigator.clipboard.writeText(text);
    alert('Report copied! Opening Instagram... Paste your summary in your story or message.');
    window.open(`instagram://library`, '_blank'); // Attempt to open app
    setShowShareMenu(false);
  };

  const handleShareSystem = async () => {
    const { text } = getSummaryData();
    if (navigator.share) {
      try {
        const csvContent = generateCSV();
        const file = new File([csvContent], `audit_report.csv`, { type: 'text/csv' });
        
        const shareData: ShareData = {
          title: 'Spend Smart Expense Report',
          text: text,
        };

        if (navigator.canShare && navigator.canShare({ files: [file] })) {
          shareData.files = [file];
        }

        await navigator.share(shareData);
      } catch (err) {
        if ((err as Error).name !== 'AbortError') {
          try {
            await navigator.share({ text });
          } catch (e) {}
        }
      }
    } else {
      navigator.clipboard.writeText(text);
      alert('Report summary copied to clipboard!');
    }
    setShowShareMenu(false);
  };

  const shareSingleTx = async (tx: Transaction) => {
    const text = `💸 *Expense Alert*\n\n📝 *Item:* ${tx.description}\n🏷️ *Category:* ${tx.category}\n💰 *Amount:* ₹${tx.amount.toLocaleString()}\n📅 *Date:* ${new Date(tx.date).toLocaleDateString()}\n\nShared via Spend Smart Wealth Manager.`;
    
    if (navigator.share) {
      try {
        await navigator.share({ text });
      } catch (e) {}
    } else {
      navigator.clipboard.writeText(text);
      alert('Transaction details copied!');
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-black text-white tracking-tighter uppercase">Transactions</h1>
          <p className="text-slate-500 text-[10px] font-black uppercase tracking-widest">Financial Audit Log</p>
        </div>
        <div className="flex items-center space-x-2">
          <button 
            onClick={() => setShowShareMenu(true)}
            className="bg-emerald-600 hover:bg-emerald-500 text-white border border-emerald-500/20 px-4 py-3 rounded-2xl font-black text-[10px] uppercase tracking-widest transition-all flex items-center space-x-2 active:scale-95 shadow-lg shadow-emerald-500/20 relative group overflow-hidden"
          >
            <i className="fas fa-share-nodes"></i>
            <span>Share Report</span>
          </button>
          <button 
            onClick={handleExportCSV}
            className="bg-slate-800 hover:bg-slate-700 text-slate-400 border border-slate-700 px-4 py-3 rounded-2xl font-black text-[10px] uppercase tracking-widest transition-all flex items-center space-x-2 active:scale-95"
            title="Download CSV"
          >
            <i className="fas fa-file-csv"></i>
          </button>
          <button 
            onClick={() => setShowAdd(true)}
            className="bg-emerald-600 hover:bg-emerald-500 text-white px-5 py-3 rounded-2xl font-black text-[10px] uppercase tracking-widest transition-all flex items-center space-x-2 shadow-xl shadow-emerald-500/20 active:scale-95"
          >
            <i className="fas fa-plus"></i>
            <span className="hidden sm:inline">Add Entry</span>
          </button>
        </div>
      </div>

      <div className="flex items-center space-x-2 mb-4 overflow-x-auto pb-2 scrollbar-hide">
        {['all', 'expense', 'income'].map((f) => (
          <button
            key={f}
            onClick={() => setFilter(f)}
            className={`px-5 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all whitespace-nowrap ${
              filter === f ? 'bg-emerald-600 text-white shadow-lg' : 'glass text-slate-500 hover:text-white'
            }`}
          >
            {f}
          </button>
        ))}
      </div>

      <div className="glass rounded-[32px] overflow-hidden border border-slate-800 shadow-2xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left min-w-[650px]">
            <thead>
              <tr className="bg-slate-900/50 text-slate-500 text-[9px] uppercase font-black tracking-widest">
                <th className="px-6 py-5">Date</th>
                <th className="px-6 py-5">Particulars</th>
                <th className="px-6 py-5">Category</th>
                <th className="px-6 py-5 text-right">Value</th>
                <th className="px-6 py-5 text-center">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/50">
              {filteredTx.map((t) => (
                <tr key={t.id} className="hover:bg-slate-800/30 transition-colors group">
                  <td className="px-6 py-4 text-[10px] font-bold text-slate-500">
                    {new Date(t.date).toLocaleDateString()}
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center space-x-3">
                      <p className="font-bold text-slate-200 text-sm">{t.description}</p>
                      {t.imageUrl && <i className="fas fa-paperclip text-emerald-400 text-[9px]"></i>}
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <span className="px-2.5 py-1 bg-slate-900 border border-slate-800 text-slate-500 rounded-lg text-[9px] font-black uppercase tracking-tighter">
                      {t.category}
                    </span>
                  </td>
                  <td className={`px-6 py-4 text-right font-black text-sm ${t.type === 'expense' ? 'text-rose-400' : 'text-emerald-400'}`}>
                    {t.type === 'expense' ? '-' : '+'}₹{t.amount.toLocaleString()}
                  </td>
                  <td className="px-6 py-4 text-center">
                    <div className="flex items-center justify-center space-x-1">
                      <button 
                        onClick={() => shareSingleTx(t)}
                        className="text-slate-600 hover:text-emerald-400 transition-all opacity-0 group-hover:opacity-100 p-2"
                        title="Share this entry"
                      >
                        <i className="fas fa-share-nodes"></i>
                      </button>
                      <button 
                        onClick={() => deleteTx(t.id)}
                        className="text-slate-700 hover:text-rose-500 transition-all opacity-0 group-hover:opacity-100 p-2"
                        title="Delete entry"
                      >
                        <i className="fas fa-trash-can"></i>
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {filteredTx.length === 0 && (
            <div className="py-24 text-center text-slate-700 italic flex flex-col items-center">
              <div className="w-20 h-20 bg-slate-900/50 rounded-full flex items-center justify-center mb-4">
                <i className="fas fa-box-open text-3xl opacity-20"></i>
              </div>
              <p className="font-black uppercase tracking-widest text-[9px]">No records found for this filter</p>
            </div>
          )}
        </div>
      </div>

      {/* Share Menu Modal */}
      {showShareMenu && (
        <div className="fixed inset-0 bg-slate-950/95 backdrop-blur-md z-[60] flex items-center justify-center p-4">
          <div className="glass w-full max-w-sm rounded-[48px] p-8 border border-slate-800 shadow-2xl animate-in zoom-in duration-200">
            <div className="flex items-center justify-between mb-8">
              <h2 className="text-xl font-black text-white uppercase tracking-tighter">Share Report</h2>
              <button onClick={() => setShowShareMenu(false)} className="w-10 h-10 rounded-full bg-slate-800 text-slate-400 hover:text-white transition-all">
                <i className="fas fa-xmark"></i>
              </button>
            </div>

            <div className="space-y-4">
              <button 
                onClick={shareToWhatsApp}
                className="w-full flex items-center space-x-4 p-5 rounded-3xl bg-emerald-600/10 border border-emerald-500/20 hover:bg-emerald-600 transition-all group"
              >
                <div className="w-12 h-12 rounded-2xl bg-[#25D366] flex items-center justify-center text-white shadow-lg">
                  <i className="fab fa-whatsapp text-2xl"></i>
                </div>
                <div className="text-left">
                  <p className="text-xs font-black text-white uppercase tracking-widest group-hover:text-white">WhatsApp</p>
                  <p className="text-[10px] text-slate-500 font-bold group-hover:text-emerald-100">Send direct message</p>
                </div>
              </button>

              <button 
                onClick={shareToInstagram}
                className="w-full flex items-center space-x-4 p-5 rounded-3xl bg-rose-600/10 border border-rose-500/20 hover:bg-rose-600 transition-all group"
              >
                <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-[#f09433] via-[#dc2743] to-[#bc1888] flex items-center justify-center text-white shadow-lg">
                  <i className="fab fa-instagram text-2xl"></i>
                </div>
                <div className="text-left">
                  <p className="text-xs font-black text-white uppercase tracking-widest group-hover:text-white">Instagram</p>
                  <p className="text-[10px] text-slate-500 font-bold group-hover:text-rose-100">Copy & open app</p>
                </div>
              </button>

              <button 
                onClick={handleShareSystem}
                className="w-full flex items-center space-x-4 p-5 rounded-3xl bg-slate-800 border border-slate-700 hover:bg-white hover:text-black transition-all group"
              >
                <div className="w-12 h-12 rounded-2xl bg-slate-700 flex items-center justify-center text-white shadow-lg group-hover:bg-black">
                  <i className="fas fa-ellipsis-h text-xl"></i>
                </div>
                <div className="text-left">
                  <p className="text-xs font-black text-white group-hover:text-black uppercase tracking-widest">More Apps</p>
                  <p className="text-[10px] text-slate-500 font-bold group-hover:text-black/60">System share sheet</p>
                </div>
              </button>
            </div>

            <div className="mt-8 p-4 bg-slate-900/50 rounded-2xl border border-slate-800">
               <p className="text-[9px] font-black text-slate-500 uppercase tracking-widest mb-2">Preview Summary</p>
               <p className="text-[10px] text-slate-400 italic line-clamp-3">"{getSummaryData().text}"</p>
            </div>
          </div>
        </div>
      )}

      {showAdd && (
        <div className="fixed inset-0 bg-slate-950/95 backdrop-blur-md z-50 flex items-center justify-center p-4">
          <div className="glass w-full max-w-lg rounded-[48px] p-8 border border-slate-800 shadow-2xl animate-in zoom-in duration-200">
            <div className="flex items-center justify-between mb-8">
              <h2 className="text-xl font-black text-white uppercase tracking-tighter">New Entry</h2>
              <button onClick={() => setShowAdd(false)} className="w-10 h-10 rounded-full bg-slate-800 text-slate-400 hover:text-white transition-all">
                <i className="fas fa-xmark"></i>
              </button>
            </div>

            <form onSubmit={addTransaction} className="space-y-5">
              <div className="grid grid-cols-2 gap-3 p-1 bg-slate-900 rounded-2xl border border-slate-800">
                <button 
                  type="button"
                  onClick={() => setNewTx({ ...newTx, type: 'expense' })}
                  className={`py-3 rounded-xl font-black uppercase text-[10px] tracking-widest transition-all ${newTx.type === 'expense' ? 'bg-rose-500 text-white' : 'text-slate-500'}`}
                >
                  Expense
                </button>
                <button 
                  type="button"
                  onClick={() => setNewTx({ ...newTx, type: 'income' })}
                  className={`py-3 rounded-xl font-black uppercase text-[10px] tracking-widest transition-all ${newTx.type === 'income' ? 'bg-emerald-600 text-white' : 'text-slate-500'}`}
                >
                  Income
                </button>
              </div>

              <div>
                <label className="block text-slate-500 text-[9px] font-black uppercase tracking-[0.2em] mb-2 ml-1">Amount (₹)</label>
                <input 
                  type="number" 
                  step="0.01"
                  required
                  value={newTx.amount}
                  onChange={(e) => setNewTx({ ...newTx, amount: e.target.value })}
                  className="w-full bg-slate-900 border border-slate-800 rounded-2xl px-6 py-4 text-white focus:ring-1 focus:ring-emerald-500 outline-none font-black text-xl"
                  placeholder="0.00"
                />
              </div>

              <div>
                <label className="block text-slate-500 text-[9px] font-black uppercase tracking-[0.2em] mb-2 ml-1">Description</label>
                <input 
                  type="text" 
                  required
                  value={newTx.description}
                  onChange={(e) => setNewTx({ ...newTx, description: e.target.value })}
                  className="w-full bg-slate-900 border border-slate-800 rounded-2xl px-6 py-4 text-white focus:ring-1 focus:ring-emerald-500 outline-none text-sm font-bold"
                  placeholder="Item description"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-slate-500 text-[9px] font-black uppercase tracking-[0.2em] mb-2 ml-1">Category</label>
                  <select 
                    value={newTx.category}
                    onChange={(e) => setNewTx({ ...newTx, category: e.target.value as Category })}
                    className="w-full bg-slate-900 border border-slate-800 rounded-2xl px-5 py-4 text-white focus:ring-1 focus:ring-emerald-500 outline-none text-[10px] font-black uppercase"
                  >
                    {CATEGORIES.map(c => <option key={c} value={c}>{c}</option>)}
                  </select>
                </div>
                <div>
                  <label className="block text-slate-500 text-[9px] font-black uppercase tracking-[0.2em] mb-2 ml-1">Date</label>
                  <input 
                    type="date" 
                    required
                    value={newTx.date}
                    onChange={(e) => setNewTx({ ...newTx, date: e.target.value })}
                    className="w-full bg-slate-900 border border-slate-800 rounded-2xl px-5 py-4 text-white focus:ring-1 focus:ring-emerald-500 outline-none text-[10px] font-black"
                  />
                </div>
              </div>

              <button 
                type="submit"
                className="w-full bg-emerald-600 hover:bg-emerald-500 text-white font-black uppercase tracking-[0.3em] text-[10px] py-5 rounded-2xl shadow-xl shadow-emerald-500/20 mt-4 transition-all"
              >
                Save Record
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default Transactions;
