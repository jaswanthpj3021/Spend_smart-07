
import React, { useState, useEffect } from 'react';
import { User, Category, Budget } from '../types';

const SUGGESTED_CATEGORIES = ['Food', 'Transport', 'Shopping', 'Rent', 'Entertainment', 'Education', 'Health', 'Other'];

const BudgetPage: React.FC<{ user: User, setUser: (u: User) => void }> = ({ user, setUser }) => {
  const [selectedPeriod, setSelectedPeriod] = useState<'monthly' | 'weekly'>('monthly');
  const [budgets, setBudgets] = useState<Budget[]>(() => {
    const saved = localStorage.getItem('smartspend_budgets');
    const initial = saved ? JSON.parse(saved) : [];
    
    // Ensure all suggested categories are represented for BOTH periods
    const periods: ('monthly' | 'weekly')[] = ['monthly', 'weekly'];
    let full = [...initial];
    
    periods.forEach(p => {
      const missing = SUGGESTED_CATEGORIES.filter(c => !full.find((b: Budget) => b.category === c && b.period === p));
      full = [
        ...full,
        ...missing.map(c => ({
          id: Math.random().toString(36).substr(2, 9),
          userId: user.id,
          category: c,
          limit: 0,
          period: p
        }))
      ];
    });
    
    return full;
  });

  const [editingGlobal, setEditingGlobal] = useState(false);
  const [newGlobalLimit, setNewGlobalLimit] = useState(user.totalBudget.toString());
  
  const [editingCatId, setEditingCatId] = useState<string | null>(null);
  const [editValue, setEditValue] = useState('');

  useEffect(() => {
    localStorage.setItem('smartspend_budgets', JSON.stringify(budgets));
  }, [budgets]);

  const updateGlobalBudget = () => {
    setUser({ ...user, totalBudget: parseFloat(newGlobalLimit) || 0 });
    setEditingGlobal(false);
  };

  const handleEditCat = (budget: Budget) => {
    setEditingCatId(budget.id);
    setEditValue(budget.limit.toString());
  };

  const saveCatLimit = (id: string) => {
    const updated = budgets.map(b => b.id === id ? { ...b, limit: parseFloat(editValue) || 0 } : b);
    setBudgets(updated);
    setEditingCatId(null);
  };

  const currentPeriodBudgets = budgets.filter(b => b.period === selectedPeriod);

  return (
    <div className="space-y-8 pb-10">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <h1 className="text-3xl font-black text-white tracking-tighter">Limit Architect</h1>
          <p className="text-slate-500 text-sm font-medium uppercase tracking-widest">Global & Category Control</p>
        </div>
        <div className="flex bg-slate-900 rounded-2xl p-1 border border-slate-800 w-fit">
           <button 
             onClick={() => setSelectedPeriod('monthly')}
             className={`px-4 py-1.5 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${selectedPeriod === 'monthly' ? 'bg-emerald-600 text-white' : 'text-slate-500 hover:text-white'}`}
           >
             Monthly
           </button>
           <button 
             onClick={() => setSelectedPeriod('weekly')}
             className={`px-4 py-1.5 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${selectedPeriod === 'weekly' ? 'bg-emerald-600 text-white' : 'text-slate-500 hover:text-white'}`}
           >
             Weekly
           </button>
        </div>
      </div>

      {/* Global Limit Card */}
      <div className="glass p-8 rounded-[40px] relative overflow-hidden bg-gradient-to-br from-emerald-600/10 via-slate-900/40 to-transparent border border-emerald-500/20 shadow-2xl">
        <div className="absolute top-0 right-0 w-64 h-64 bg-emerald-500/10 rounded-full -mr-32 -mt-32 blur-[120px] pointer-events-none"></div>
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between mb-8 gap-6">
          <div className="relative z-10">
            <span className="text-emerald-400 text-[10px] font-black uppercase tracking-[0.4em] mb-4 block">Primary Expenditure Cap ({selectedPeriod})</span>
            <div className="flex items-center space-x-4">
              {editingGlobal ? (
                <div className="flex items-center space-x-3 bg-slate-950 p-2 rounded-3xl border border-emerald-500/50 shadow-inner">
                  <span className="text-emerald-400 text-3xl font-black ml-4">₹</span>
                  <input 
                    type="number"
                    value={newGlobalLimit}
                    onChange={(e) => setNewGlobalLimit(e.target.value)}
                    className="bg-transparent text-white text-4xl sm:text-5xl font-black w-40 sm:w-60 focus:outline-none"
                    autoFocus
                  />
                  <button onClick={updateGlobalBudget} className="bg-emerald-600 w-12 h-12 sm:w-14 sm:h-14 rounded-2xl hover:bg-emerald-500 transition-all flex items-center justify-center text-white text-xl shadow-lg active:scale-90">
                    <i className="fas fa-check"></i>
                  </button>
                </div>
              ) : (
                <div className="flex items-center space-x-4">
                  <p className="text-5xl sm:text-7xl font-black text-white tracking-tighter">₹{user.totalBudget.toLocaleString()}</p>
                  <button onClick={() => setEditingGlobal(true)} className="w-10 h-10 sm:w-12 sm:h-12 rounded-2xl bg-slate-800 text-slate-400 hover:bg-emerald-600 hover:text-white transition-all shadow-xl flex items-center justify-center active:scale-90">
                    <i className="fas fa-pen-nib text-sm sm:text-base"></i>
                  </button>
                </div>
              )}
            </div>
          </div>
          <div className="hidden lg:flex w-24 h-24 bg-emerald-600/20 rounded-[32px] items-center justify-center border border-emerald-500/30 rotate-12 shadow-2xl shadow-emerald-500/10">
            <i className="fas fa-indian-rupee-sign text-emerald-400 text-5xl"></i>
          </div>
        </div>
        <div className="flex items-center space-x-2 text-slate-500 text-xs font-bold uppercase tracking-wider bg-slate-950/40 p-3 rounded-2xl w-fit">
          <i className="fas fa-shield-halved text-emerald-500"></i>
          <p>Strict Limit Policy Active</p>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {currentPeriodBudgets.map(budget => {
          const isEditing = editingCatId === budget.id;
          return (
            <div key={budget.id} className="glass p-6 rounded-[32px] border border-slate-800 hover:border-emerald-500/40 transition-all group relative overflow-hidden flex flex-col">
              <div className="flex justify-between items-start mb-6">
                <div className="flex items-center space-x-3">
                  <div className="w-12 h-12 bg-slate-950 border border-slate-800 rounded-2xl flex items-center justify-center text-slate-500 group-hover:text-emerald-400 group-hover:border-emerald-500/20 transition-all shadow-lg">
                    <i className={`fas ${
                      budget.category === 'Food' ? 'fa-bowl-food' : 
                      budget.category === 'Transport' ? 'fa-bus' : 
                      budget.category === 'Shopping' ? 'fa-bag-shopping' : 
                      budget.category === 'Entertainment' ? 'fa-gamepad' :
                      budget.category === 'Education' ? 'fa-graduation-cap' :
                      budget.category === 'Health' ? 'fa-heart-pulse' :
                      'fa-list-check'
                    } text-xl`}></i>
                  </div>
                  <h3 className="font-black text-white uppercase text-[10px] tracking-[0.2em]">{budget.category}</h3>
                </div>
              </div>
              
              <div className="space-y-1 mb-6">
                <p className="text-[10px] text-slate-600 uppercase font-black tracking-widest">Allocation ({selectedPeriod})</p>
                {isEditing ? (
                  <div className="flex items-center space-x-2">
                     <span className="text-emerald-400 font-black">₹</span>
                     <input 
                      type="number"
                      autoFocus
                      value={editValue}
                      onChange={(e) => setEditValue(e.target.value)}
                      onBlur={() => saveCatLimit(budget.id)}
                      onKeyDown={(e) => e.key === 'Enter' && saveCatLimit(budget.id)}
                      className="bg-slate-950 border border-emerald-500/30 rounded-lg px-2 py-1 text-white font-black text-xl w-full focus:outline-none"
                     />
                  </div>
                ) : (
                  <p className="text-2xl font-black text-white">₹{budget.limit.toLocaleString()}</p>
                )}
              </div>

              <div className="w-full bg-slate-950 h-1.5 rounded-full overflow-hidden mb-6 shadow-inner">
                <div 
                  className="bg-emerald-600 h-full rounded-full shadow-[0_0_12px_rgba(16,185,129,0.4)] transition-all duration-1000" 
                  style={{ width: user.totalBudget > 0 ? `${Math.min((budget.limit / user.totalBudget) * 100, 100)}%` : '0%' }}
                ></div>
              </div>

              <button 
                onClick={() => handleEditCat(budget)}
                className={`mt-auto w-full py-3 ${isEditing ? 'bg-emerald-600 text-white' : 'bg-slate-800/40 hover:bg-emerald-600 text-slate-500 hover:text-white'} rounded-2xl text-[10px] font-black uppercase tracking-widest transition-all active:scale-95`}
              >
                {isEditing ? 'Save New Limit' : 'Modify Limit'}
              </button>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default BudgetPage;
