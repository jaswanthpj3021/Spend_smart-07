
import React, { useState, useEffect, useRef } from 'react';
import { User, Note } from '../types';

const NOTES_COLORS = ['bg-yellow-400/20', 'bg-indigo-400/20', 'bg-emerald-400/20', 'bg-rose-400/20', 'bg-sky-400/20'];

const Notes: React.FC<{ user: User }> = ({ user }) => {
  const [notes, setNotes] = useState<Note[]>(() => {
    const saved = localStorage.getItem('smartspend_notes');
    return saved ? JSON.parse(saved) : [];
  });
  const [showAdd, setShowAdd] = useState(false);
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [imageUrl, setImageUrl] = useState<string | null>(null);
  
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    localStorage.setItem('smartspend_notes', JSON.stringify(notes));
  }, [notes]);

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setImageUrl(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const addNote = (e: React.FormEvent) => {
    e.preventDefault();
    const newNote: Note = {
      id: Date.now().toString(),
      userId: user.id,
      title,
      content,
      createdAt: new Date().toISOString(),
      color: NOTES_COLORS[Math.floor(Math.random() * NOTES_COLORS.length)],
      imageUrl: imageUrl || undefined
    };
    setNotes([newNote, ...notes]);
    setTitle('');
    setContent('');
    setImageUrl(null);
    setShowAdd(false);
  };

  const deleteNote = (id: string) => {
    setNotes(notes.filter(n => n.id !== id));
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">Receipt Notes</h1>
          <p className="text-slate-400 text-sm">Attach photos of receipts or items for reference</p>
        </div>
        <button 
          onClick={() => setShowAdd(true)}
          className="bg-indigo-600 hover:bg-indigo-500 text-white px-4 py-2 rounded-xl flex items-center space-x-2 transition-all shadow-lg"
        >
          <i className="fas fa-plus"></i>
          <span>New Note</span>
        </button>
      </div>

      {showAdd && (
        <div className="glass p-6 rounded-2xl border border-indigo-500/20 animate-in fade-in slide-in-from-top-4 overflow-hidden relative">
          <div className="absolute top-0 left-0 w-1 h-full bg-indigo-500"></div>
          <form onSubmit={addNote} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-4">
                <input 
                  type="text" 
                  placeholder="Subject (e.g. New Laptop Purchase)" 
                  required
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-800 rounded-xl px-4 py-3 text-white font-bold focus:ring-1 focus:ring-indigo-500 outline-none"
                />
                <textarea 
                  placeholder="Add specific details or reminders here..." 
                  required
                  rows={4}
                  value={content}
                  onChange={(e) => setContent(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-800 rounded-xl px-4 py-3 text-white text-sm focus:ring-1 focus:ring-indigo-500 outline-none"
                ></textarea>
              </div>

              <div className="flex flex-col">
                <div 
                  onClick={() => fileInputRef.current?.click()}
                  className="flex-1 min-h-[160px] bg-slate-900 border-2 border-dashed border-slate-800 rounded-2xl flex flex-col items-center justify-center cursor-pointer hover:border-indigo-500/50 hover:bg-slate-800/50 transition-all group relative overflow-hidden"
                >
                  {imageUrl ? (
                    <>
                      <img src={imageUrl} alt="Receipt Preview" className="absolute inset-0 w-full h-full object-cover" />
                      <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity">
                         <i className="fas fa-camera text-white text-2xl"></i>
                      </div>
                    </>
                  ) : (
                    <>
                      <i className="fas fa-receipt text-3xl text-slate-700 mb-2 group-hover:text-indigo-400"></i>
                      <p className="text-slate-600 text-[10px] font-black uppercase tracking-widest group-hover:text-white">Click to upload photo</p>
                    </>
                  )}
                </div>
                <input type="file" ref={fileInputRef} className="hidden" accept="image/*" onChange={handleImageUpload} />
              </div>
            </div>

            <div className="flex justify-end space-x-2 pt-2">
              <button type="button" onClick={() => { setShowAdd(false); setImageUrl(null); }} className="px-4 py-2 text-slate-400 hover:text-white font-bold">Cancel</button>
              <button type="submit" className="px-8 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl font-bold shadow-xl shadow-indigo-600/20 active:scale-95">Save Entry</button>
            </div>
          </form>
        </div>
      )}

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {notes.map((note) => (
          <div key={note.id} className={`${note.color} rounded-[32px] border border-white/5 relative group overflow-hidden flex flex-col`}>
            {note.imageUrl && (
              <div className="w-full h-40 overflow-hidden relative">
                <img src={note.imageUrl} alt={note.title} className="w-full h-full object-cover grayscale-[0.2] group-hover:grayscale-0 transition-all duration-500" />
                <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent"></div>
              </div>
            )}
            <div className="p-6">
              <div className="flex justify-between items-start mb-2">
                <h3 className="font-bold text-white text-lg">{note.title}</h3>
                <button 
                  onClick={() => deleteNote(note.id)}
                  className="text-white/20 hover:text-rose-400 transition-all"
                >
                  <i className="fas fa-trash-can text-sm"></i>
                </button>
              </div>
              <p className="text-slate-300 text-sm leading-relaxed mb-6">{note.content}</p>
              <div className="flex items-center justify-between mt-auto">
                <p className="text-[10px] text-slate-400 uppercase font-black tracking-widest">{new Date(note.createdAt).toLocaleDateString('en-IN')}</p>
                <div className="w-6 h-6 rounded-full bg-white/10 flex items-center justify-center">
                  <i className={`fas ${note.imageUrl ? 'fa-image' : 'fa-align-left'} text-[10px] text-white/40`}></i>
                </div>
              </div>
            </div>
          </div>
        ))}
        {notes.length === 0 && !showAdd && (
          <div className="col-span-full py-24 text-center glass rounded-[48px] border-2 border-dashed border-slate-800 flex flex-col items-center">
            <div className="w-20 h-20 bg-slate-900 rounded-full flex items-center justify-center mb-6">
              <i className="fas fa-camera-retro text-4xl text-slate-700 opacity-30"></i>
            </div>
            <h3 className="text-white font-bold mb-2">No Visual Logs</h3>
            <p className="text-slate-500 text-xs max-w-xs mx-auto">Digitize your physical receipts and expense thoughts here.</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default Notes;
