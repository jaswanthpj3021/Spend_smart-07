
import React, { useState, useRef } from 'react';
import { User, Theme, CustomTheme } from '../types';

interface ProfileProps {
  user: User;
  onLogout: () => void;
  onUpdateUser: (user: User) => void;
  theme: Theme;
  setTheme: (theme: Theme) => void;
  customThemes: CustomTheme[];
  setCustomThemes: React.Dispatch<React.SetStateAction<CustomTheme[]>>;
  activeCustomThemeId: string | null;
  setActiveCustomThemeId: (id: string | null) => void;
}

const Profile: React.FC<ProfileProps> = ({ 
  user, 
  onLogout, 
  onUpdateUser, 
  theme, 
  setTheme,
  customThemes,
  setCustomThemes,
  activeCustomThemeId,
  setActiveCustomThemeId
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isEditingName, setIsEditingName] = useState(false);
  const [editNameValue, setEditNameValue] = useState(user.name);
  const [copyStatus, setCopyStatus] = useState('Copy');
  
  const [showCreator, setShowCreator] = useState(false);
  const [showPasswordChange, setShowPasswordChange] = useState(false);
  const [passwordForm, setPasswordForm] = useState({ current: '', new: '', confirm: '' });
  
  const [newTheme, setNewTheme] = useState<Omit<CustomTheme, 'id'>>({
    name: 'My Vibe',
    bg: '#020617',
    text: '#f8fafc',
    accent: '#10b981'
  });

  const handleCopyPjId = () => {
    navigator.clipboard.writeText(user.pjId);
    setCopyStatus('Copied!');
    setTimeout(() => setCopyStatus('Copy'), 2000);
  };

  const handleAvatarChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        const base64 = reader.result as string;
        onUpdateUser({ ...user, avatar: base64 });
      };
      reader.readAsDataURL(file);
    }
  };

  const handleNameSave = () => {
    if (editNameValue.trim()) {
      onUpdateUser({ ...user, name: editNameValue });
      setIsEditingName(false);
    }
  };

  const handlePasswordUpdate = (e: React.FormEvent) => {
    e.preventDefault();
    if (passwordForm.new !== passwordForm.confirm) {
      alert("New passwords do not match!");
      return;
    }
    // Simulation logic
    alert("Credential update verified and synchronized with local vault!");
    setShowPasswordChange(false);
    setPasswordForm({ current: '', new: '', confirm: '' });
  };

  const handleExportAllData = async (shouldShare = false) => {
    const exportData = {
      user: JSON.parse(localStorage.getItem('smartspend_user') || '{}'),
      transactions: JSON.parse(localStorage.getItem('smartspend_transactions') || '[]'),
      budgets: JSON.parse(localStorage.getItem('smartspend_budgets') || '[]'),
      exportedAt: new Date().toISOString()
    };

    const jsonString = JSON.stringify(exportData, null, 2);
    const fileName = `spend_smart_report_${new Date().toISOString().split('T')[0]}.json`;

    if (shouldShare && navigator.share) {
      try {
        const file = new File([jsonString], fileName, { type: 'application/json' });
        const shareConfig: ShareData = {
          title: 'Spend Smart Wealth Report',
          text: `Financial audit for ${user.name}. Track your wealth with Kuber! 🚀`,
        };

        if (navigator.canShare && navigator.canShare({ files: [file] })) {
          shareConfig.files = [file];
        }

        await navigator.share(shareConfig);
        return;
      } catch (err) {
        console.error('Sharing failed:', err);
      }
    }

    const blob = new Blob([jsonString], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = fileName;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const saveCustomTheme = () => {
    const id = Date.now().toString();
    const themeToSave = { ...newTheme, id };
    setCustomThemes([...customThemes, themeToSave]);
    setActiveCustomThemeId(id);
    setTheme(Theme.CUSTOM);
    setShowCreator(false);
  };

  const deleteCustomTheme = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    const updated = customThemes.filter(t => t.id !== id);
    setCustomThemes(updated);
    if (activeCustomThemeId === id) {
      setActiveCustomThemeId(updated.length > 0 ? updated[0].id : null);
      if (updated.length === 0) setTheme(Theme.DARK);
    }
  };

  const themeOptions = [
    { id: Theme.DARK, name: 'Midnight', icon: 'fa-moon', color: 'bg-slate-900' },
    { id: Theme.LIGHT, name: 'Pure', icon: 'fa-sun', color: 'bg-white' },
    { id: Theme.NEON, name: 'Vapor', icon: 'fa-bolt-lightning', color: 'bg-indigo-900' },
    { id: Theme.CYBERPUNK, name: 'Grid', icon: 'fa-robot', color: 'bg-black' },
    { id: Theme.LUXURY, name: 'Gold', icon: 'fa-gem', color: 'bg-[#0a0a0a]' },
    { id: Theme.ATLANTIS, name: 'Ocean', icon: 'fa-water', color: 'bg-[#002b36]' },
    { id: Theme.MARS, name: 'Magma', icon: 'fa-fire', color: 'bg-[#1a0505]' },
    { id: Theme.LAVENDER, name: 'Silk', icon: 'fa-wand-sparkles', color: 'bg-[#120a1a]' },
  ];

  const getAccentColor = (currentTheme: Theme) => {
    if (currentTheme === Theme.CUSTOM) {
      return 'text-[var(--accent-color)]';
    }
    switch (currentTheme) {
      case Theme.LUXURY: return 'text-[#d4af37]';
      case Theme.ATLANTIS: return 'text-[#2aa198]';
      case Theme.MARS: return 'text-[#ff4d4d]';
      case Theme.LAVENDER: return 'text-[#e0b0ff]';
      default: return 'text-emerald-400';
    }
  };

  return (
    <div className="max-w-2xl mx-auto py-4 px-4 sm:px-0 pb-32">
      <div className="text-center mb-8">
        <div className="relative inline-block">
          <div className="w-28 h-28 sm:w-32 sm:h-32 rounded-[32px] border-4 border-emerald-600/30 p-1 mb-4 shadow-xl overflow-hidden bg-slate-900">
            {user.avatar ? (
              <img src={user.avatar} alt="Profile" className="w-full h-full object-cover rounded-[28px]" />
            ) : (
              <div className="w-full h-full bg-emerald-600 flex items-center justify-center rounded-[28px]">
                <i className="fas fa-user-ninja text-white text-4xl"></i>
              </div>
            )}
          </div>
          <input type="file" ref={fileInputRef} className="hidden" accept="image/*" onChange={handleAvatarChange} />
          <button 
            onClick={() => fileInputRef.current?.click()}
            className="absolute bottom-6 right-0 bg-emerald-600 w-10 h-10 rounded-xl border-4 border-slate-950 flex items-center justify-center text-white hover:bg-emerald-500 transition-all shadow-xl"
          >
            <i className="fas fa-camera text-xs"></i>
          </button>
        </div>
        
        <div className="flex flex-col items-center">
          {isEditingName ? (
            <div className="flex items-center space-x-2 bg-slate-900 border border-slate-800 rounded-2xl p-1 pr-1.5 animate-in slide-in-from-top-2">
              <input 
                type="text"
                value={editNameValue}
                onChange={(e) => setEditNameValue(e.target.value)}
                autoFocus
                className="bg-transparent text-white px-3 py-1 font-black uppercase text-xl focus:outline-none"
              />
              <button 
                onClick={handleNameSave}
                className="bg-emerald-600 w-8 h-8 rounded-lg flex items-center justify-center text-white text-xs hover:bg-emerald-500"
              >
                <i className="fas fa-check"></i>
              </button>
            </div>
          ) : (
            <div className="flex items-center space-x-3 group">
              <h1 className="text-3xl font-black text-inherit tracking-tighter uppercase">{user.name}</h1>
              <button 
                onClick={() => setIsEditingName(true)}
                className="opacity-0 group-hover:opacity-100 w-8 h-8 rounded-lg bg-slate-800 text-slate-400 hover:text-white transition-all flex items-center justify-center"
              >
                <i className="fas fa-pen text-[10px]"></i>
              </button>
            </div>
          )}
          <p className="text-slate-500 font-black uppercase text-[8px] tracking-[0.2em] mt-2">Verified Authenticator since {new Date(user.memberSince).getFullYear()}</p>
        </div>
      </div>

      <div className="space-y-6">
        <div className="glass p-6 rounded-[32px] border border-emerald-500/20 shadow-xl bg-gradient-to-br from-emerald-600/5 to-transparent">
           <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
              <div>
                 <p className="text-[10px] font-black text-emerald-500 uppercase tracking-[0.3em] mb-1">Global Terminal ID</p>
                 <h2 className="text-2xl font-black text-white tracking-tighter uppercase">{user.pjId || 'PJ-0000000'}</h2>
                 <p className="text-[8px] font-bold text-slate-500 uppercase tracking-widest mt-1">Search this key to connect with peer nodes</p>
              </div>
              <button 
                onClick={handleCopyPjId}
                className="px-6 py-3 bg-emerald-600 hover:bg-emerald-500 text-white rounded-2xl text-[10px] font-black uppercase tracking-widest transition-all shadow-lg active:scale-95 flex items-center space-x-2"
              >
                <i className={copyStatus === 'Copy' ? 'fas fa-copy' : 'fas fa-check'}></i>
                <span>{copyStatus}</span>
              </button>
           </div>
        </div>

        {/* Improved Password Management Section */}
        <div className="glass p-6 rounded-[32px] border border-slate-800 shadow-lg overflow-hidden bg-slate-900/20">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-[10px] font-black text-slate-500 uppercase tracking-[0.3em] flex items-center">
              <i className="fas fa-key-skeleton mr-2 text-emerald-500"></i>
              Security Credentials
            </h3>
            <button 
              onClick={() => setShowPasswordChange(!showPasswordChange)}
              className={`text-[9px] font-black uppercase tracking-widest px-3 py-1.5 rounded-lg transition-all ${showPasswordChange ? 'bg-rose-500/10 text-rose-500 hover:bg-rose-500 hover:text-white' : 'bg-slate-800 hover:bg-slate-700 text-slate-300'}`}
            >
              {showPasswordChange ? 'Discard' : 'Modify Key'}
            </button>
          </div>

          {showPasswordChange ? (
            <form onSubmit={handlePasswordUpdate} className="space-y-4 animate-in slide-in-from-top-2">
              <div className="space-y-3">
                <div className="relative">
                  <input 
                    type="password"
                    placeholder="Current Key"
                    required
                    value={passwordForm.current}
                    onChange={e => setPasswordForm({...passwordForm, current: e.target.value})}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 text-xs text-white focus:outline-none focus:ring-1 focus:ring-emerald-500 transition-all placeholder-slate-700"
                  />
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <input 
                    type="password"
                    placeholder="New Secure Key"
                    required
                    value={passwordForm.new}
                    onChange={e => setPasswordForm({...passwordForm, new: e.target.value})}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 text-xs text-white focus:outline-none focus:ring-1 focus:ring-emerald-500 transition-all placeholder-slate-700"
                  />
                  <input 
                    type="password"
                    placeholder="Confirm New Key"
                    required
                    value={passwordForm.confirm}
                    onChange={e => setPasswordForm({...passwordForm, confirm: e.target.value})}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 text-xs text-white focus:outline-none focus:ring-1 focus:ring-emerald-500 transition-all placeholder-slate-700"
                  />
                </div>
              </div>
              <button 
                type="submit"
                className="w-full bg-emerald-600 hover:bg-emerald-500 text-white font-black uppercase tracking-widest text-[10px] py-3 rounded-xl transition-all shadow-lg active:scale-95 flex items-center justify-center"
              >
                <i className="fas fa-check-double mr-2"></i>
                Synchronize Credentials
              </button>
            </form>
          ) : (
            <p className="text-[10px] text-slate-600 font-bold uppercase leading-relaxed max-w-sm">
              Vault access is governed by high-entropy credentials. Cycle your keys regularly to maintain absolute privacy.
            </p>
          )}
        </div>

        <div className="glass p-6 rounded-[32px] border border-slate-800 shadow-lg">
          <h3 className="text-[10px] font-black text-slate-500 uppercase tracking-[0.3em] mb-6 flex items-center">
            <i className="fas fa-fingerprint mr-2 text-emerald-500"></i>
            Neural Statistics
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="bg-slate-950/50 p-4 rounded-2xl border border-slate-800/50">
               <p className="text-[8px] font-black text-slate-600 uppercase tracking-widest mb-1">Architecture</p>
               <p className="text-[10px] font-mono font-bold text-slate-300">v3.0.0-INDIA</p>
            </div>
            <div className="bg-slate-950/50 p-4 rounded-2xl border border-slate-800/50">
               <p className="text-[8px] font-black text-slate-600 uppercase tracking-widest mb-1">Account Tier</p>
               <div className="flex items-center space-x-2">
                 <i className="fas fa-crown text-[10px] text-yellow-500"></i>
                 <p className="text-[10px] font-bold text-slate-300 uppercase">Master Budgeter</p>
               </div>
            </div>
            <div className="bg-slate-950/50 p-4 rounded-2xl border border-slate-800/50">
               <p className="text-[8px] font-black text-slate-600 uppercase tracking-widest mb-1">Status</p>
               <div className="flex items-center space-x-2">
                 <div className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-pulse shadow-[0_0_8px_rgba(16,185,129,0.8)]"></div>
                 <p className="text-[10px] font-bold text-emerald-400">ACTIVE</p>
               </div>
            </div>
            <div className="bg-slate-950/50 p-4 rounded-2xl border border-slate-800/50">
               <p className="text-[8px] font-black text-slate-600 uppercase tracking-widest mb-1">Encryption</p>
               <div className="flex items-center space-x-2">
                 <i className="fas fa-lock text-[10px] text-emerald-500"></i>
                 <p className="text-[10px] font-bold text-slate-300">LOCAL-FIRST AES</p>
               </div>
            </div>
          </div>
        </div>

        <div className="glass p-6 rounded-[32px] border border-slate-800 shadow-lg">
          <h3 className="text-[10px] font-black text-slate-500 uppercase tracking-[0.3em] mb-6">Visual Style Library</h3>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-6">
            {themeOptions.map(opt => (
              <button 
                key={opt.id}
                onClick={() => setTheme(opt.id)}
                className={`flex flex-col items-center justify-center p-3 rounded-2xl border-2 transition-all ${
                  theme === opt.id 
                    ? 'border-emerald-500 bg-emerald-600/10' 
                    : 'border-slate-800 bg-slate-900/40 hover:border-slate-600'
                }`}
              >
                <div className={`w-8 h-8 rounded-lg mb-2 flex items-center justify-center ${opt.color} border border-white/5 shadow-md`}>
                   <i className={`fas ${opt.icon} ${theme === opt.id ? getAccentColor(opt.id) : 'text-slate-400'} text-xs`}></i>
                </div>
                <span className={`text-[9px] font-black uppercase tracking-widest ${theme === opt.id ? getAccentColor(opt.id) : 'text-slate-500'}`}>
                  {opt.name}
                </span>
              </button>
            ))}
          </div>
        </div>

        <div className="space-y-4">
          <button 
            onClick={onLogout}
            className="w-full py-4 bg-rose-600/10 text-rose-500 border border-rose-500/20 hover:bg-rose-600 hover:text-white rounded-[24px] font-black uppercase tracking-[0.3em] text-[10px] transition-all shadow-xl active:scale-95 flex items-center justify-center space-x-2"
          >
            <i className="fas fa-power-off"></i>
            <span>Secure Vault Lock</span>
          </button>

          <div className="pt-8 flex flex-col items-center justify-center opacity-40">
             <div className="flex items-center space-x-3 mb-2">
               <span className="text-[10px] font-black uppercase tracking-[0.4em] text-slate-400">Proudly Made in India</span>
               <span className="text-2xl grayscale-0">🇮🇳</span>
             </div>
             <p className="text-[8px] font-bold text-slate-600 uppercase tracking-widest">Architected for Financial Sovereignty</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Profile;
