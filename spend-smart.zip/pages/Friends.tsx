
import React, { useState, useEffect, useRef } from 'react';
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, Legend, CartesianGrid } from 'recharts';
import { User, Friend, FriendRequest, Transaction, PrivateMessage } from '../types';

interface FriendsProps {
  user: User;
  onNotify: (message: string, type?: 'info' | 'success' | 'warning') => void;
}

const Friends: React.FC<FriendsProps> = ({ user, onNotify }) => {
  const [activeTab, setActiveTab] = useState<'network' | 'requests'>('network');
  const [selectedFriend, setSelectedFriend] = useState<Friend | null>(null);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState<string | null>(null); 
  const [isChatOpen, setIsChatOpen] = useState(false);
  const [chatInput, setChatInput] = useState('');
  const [searchMode, setSearchMode] = useState<'id' | 'name'>('id');
  const chatScrollRef = useRef<HTMLDivElement>(null);

  const [friends, setFriends] = useState<Friend[]>(() => {
    const saved = localStorage.getItem('smartspend_friends');
    return saved ? JSON.parse(saved) : [];
  });

  const [privateMessages, setPrivateMessages] = useState<PrivateMessage[]>(() => {
    const saved = localStorage.getItem('smartspend_private_messages');
    return saved ? JSON.parse(saved) : [];
  });

  const [permissions, setPermissions] = useState<Record<string, boolean>>(() => {
    const saved = localStorage.getItem('smartspend_friend_permissions');
    return saved ? JSON.parse(saved) : {};
  });

  const [userTransactions] = useState<Transaction[]>(() => {
    const saved = localStorage.getItem('smartspend_transactions');
    return saved ? JSON.parse(saved) : [];
  });

  const [requests, setRequests] = useState<FriendRequest[]>(() => {
    const saved = localStorage.getItem('smartspend_friend_requests');
    if (!saved) {
      return [{
        id: 'mock-1',
        senderId: 'user-xyz',
        senderPjId: 'PJ-7728109',
        senderName: 'Rahul Sharma',
        senderEmail: 'rahul@example.com',
        receiverEmail: user.email,
        status: 'pending',
        timestamp: new Date().toISOString()
      }];
    }
    return JSON.parse(saved);
  });

  const [search, setSearch] = useState('');
  const [showAdd, setShowAdd] = useState(false);
  const [newFriend, setNewFriend] = useState({ name: '', email: '', pjId: '' });

  useEffect(() => {
    localStorage.setItem('smartspend_friends', JSON.stringify(friends));
  }, [friends]);

  useEffect(() => {
    localStorage.setItem('smartspend_friend_requests', JSON.stringify(requests));
  }, [requests]);

  useEffect(() => {
    localStorage.setItem('smartspend_friend_permissions', JSON.stringify(permissions));
  }, [permissions]);

  useEffect(() => {
    localStorage.setItem('smartspend_private_messages', JSON.stringify(privateMessages));
  }, [privateMessages]);

  useEffect(() => {
    if (chatScrollRef.current) {
      chatScrollRef.current.scrollTop = chatScrollRef.current.scrollHeight;
    }
  }, [isChatOpen, privateMessages]);

  const togglePermission = (friendId: string) => {
    const newState = !permissions[friendId];
    setPermissions({ ...permissions, [friendId]: newState });
    onNotify(newState ? `Data shared with contact` : `Access revoked`, newState ? 'success' : 'info');
  };

  const handleSendRequest = (e: React.FormEvent) => {
    e.preventDefault();
    const identifier = newFriend.pjId || newFriend.email;
    
    if ((newFriend.pjId && newFriend.pjId === user.pjId) || (newFriend.email && newFriend.email === user.email)) {
      onNotify("Self-connection not permitted!", "warning");
      return;
    }

    const request: FriendRequest = {
      id: Math.random().toString(36).substr(2, 9),
      senderId: user.id,
      senderPjId: user.pjId,
      senderName: user.name,
      senderEmail: user.email,
      receiverEmail: newFriend.email || `id-${newFriend.pjId}@smartspend.internal`,
      status: 'pending',
      timestamp: new Date().toISOString()
    };
    
    setRequests([...requests, request]);
    setNewFriend({ name: '', email: '', pjId: '' });
    setShowAdd(false);
    onNotify(`Invitation sent to ${identifier}`, 'info');
  };

  const handleAcceptRequest = (request: FriendRequest) => {
    const newFriendObj: Friend = {
      id: request.senderId,
      pjId: request.senderPjId,
      name: request.senderName,
      email: request.senderEmail,
      avatar: `https://api.dicebear.com/7.x/avataaars/svg?seed=${request.senderName}`
    };
    
    setFriends([...friends, newFriendObj]);
    setRequests(requests.filter(r => r.id !== request.id));
    onNotify(`You are now friends with ${request.senderName}`, 'success');
  };

  const handleDeclineRequest = (id: string) => {
    setRequests(requests.filter(r => r.id !== id));
    onNotify('Friend request declined', 'info');
  };

  const removeFriend = (id: string) => {
    const friendName = friends.find(f => f.id === id)?.name;
    setFriends(friends.filter(f => f.id !== id));
    setSelectedFriend(null);
    setShowDeleteConfirm(null);
    setIsChatOpen(false);
    if (friendName) onNotify(`${friendName} removed from network`, 'warning');
  };

  const handleSendMessage = () => {
    if (!chatInput.trim() || !selectedFriend) return;

    const msg: PrivateMessage = {
      id: Date.now().toString(),
      senderId: user.id,
      receiverId: selectedFriend.id,
      text: chatInput,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setPrivateMessages([...privateMessages, msg]);
    setChatInput('');

    setTimeout(() => {
      const reply: PrivateMessage = {
        id: (Date.now() + 1).toString(),
        senderId: selectedFriend.id,
        receiverId: user.id,
        text: `Got your message, ${user.name.split(' ')[0]}! Checking my wealth report now.`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };
      setPrivateMessages(prev => [...prev, reply]);
    }, 1500);
  };

  const handleShareFriendProfile = async (friend: Friend) => {
    const stats = getFriendStats(friend.name);
    const shareText = `Check out my connection ${friend.name} (ID: ${friend.pjId}) on Spend Smart! 🚀\n\nFinancial Archetype: ${stats.archetype}\nConsistency Score: ${stats.consistency}%\n\nTrack your wealth with Spend Smart!`;
    
    if (navigator.share) {
      try {
        await navigator.share({
          title: `${friend.name}'s Wealth Profile`,
          text: shareText,
        });
      } catch (err) {
        if ((err as Error).name !== 'AbortError') {
          console.error('Error sharing profile:', err);
        }
      }
    } else {
      navigator.clipboard.writeText(shareText);
      onNotify('Profile link copied to clipboard!', 'info');
    }
  };

  const currentFriendMessages = selectedFriend 
    ? privateMessages.filter(m => 
        (m.senderId === user.id && m.receiverId === selectedFriend.id) || 
        (m.senderId === selectedFriend.id && m.receiverId === user.id)
      )
    : [];

  const incomingRequests = requests.filter(r => r.receiverEmail === user.email && r.status === 'pending');
  const outgoingRequests = requests.filter(r => r.senderEmail === user.email && r.status === 'pending');

  const filteredFriends = friends.filter(f => 
    f.name.toLowerCase().includes(search.toLowerCase()) || 
    f.pjId.toLowerCase().includes(search.toLowerCase()) ||
    f.email.toLowerCase().includes(search.toLowerCase())
  );

  const getFriendStats = (name: string) => {
    const seed = name.length;
    const archetypes = ["Savvy Saver", "Growth Mindset", "Budget Ninja", "Wise Investor", "Debt Crusher"];
    return {
      archetype: archetypes[seed % archetypes.length],
      score: 75 + (seed % 20),
      savings: 12000 + (seed * 500),
      consistency: 80 + (seed % 15)
    };
  };

  const getComparisonData = (friendName: string) => {
    const categories = ['Food', 'Rent', 'Travel', 'Shop', 'Other'];
    const userTotals = categories.reduce((acc, cat) => {
      acc[cat] = userTransactions
        .filter(t => t.category.toLowerCase().includes(cat.toLowerCase()) && t.type === 'expense')
        .reduce((sum, t) => sum + t.amount, 0);
      return acc;
    }, {} as any);

    return categories.map((cat, i) => ({
      name: cat,
      Me: userTotals[cat] || 1500 + (i * 200),
      [friendName.split(' ')[0]]: 1000 + (friendName.length * 50) + (i * 300)
    }));
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-black text-inherit tracking-tighter uppercase">Social Network</h1>
          <p className="opacity-60 text-sm font-medium">Connect and compare with unique PJ-IDs</p>
        </div>
        <div className="flex space-x-3">
          <button 
            onClick={() => { setShowAdd(true); setSearchMode('id'); }}
            className="bg-emerald-600 hover:bg-emerald-500 text-white px-6 py-3 rounded-2xl font-black uppercase tracking-widest text-xs transition-all flex items-center space-x-2 shadow-xl shadow-emerald-500/20 active:scale-95"
          >
            <i className="fas fa-search-dollar"></i>
            <span>Add by PJ-ID</span>
          </button>
        </div>
      </div>

      <div className="flex bg-slate-900/50 p-1.5 rounded-2xl border border-slate-800 w-fit overflow-x-auto max-w-full">
        <button 
          onClick={() => setActiveTab('network')}
          className={`px-6 py-2 rounded-xl text-xs font-black uppercase tracking-widest transition-all whitespace-nowrap ${activeTab === 'network' ? 'bg-emerald-600 text-white shadow-lg' : 'text-slate-500 hover:text-white'}`}
        >
          My Network ({friends.length})
        </button>
        <button 
          onClick={() => setActiveTab('requests')}
          className={`px-6 py-2 rounded-xl text-xs font-black uppercase tracking-widest transition-all relative whitespace-nowrap ${activeTab === 'requests' ? 'bg-emerald-600 text-white shadow-lg' : 'text-slate-500 hover:text-white'}`}
        >
          Invitations
          {incomingRequests.length > 0 && (
            <span className="absolute -top-1 -right-1 w-4 h-4 bg-rose-500 text-white text-[8px] flex items-center justify-center rounded-full animate-bounce">
              {incomingRequests.length}
            </span>
          )}
        </button>
      </div>

      {activeTab === 'network' ? (
        <>
          <div className="relative group">
            <i className="fas fa-search absolute left-4 top-1/2 -translate-y-1/2 text-slate-500 group-focus-within:text-emerald-500 transition-colors"></i>
            <input 
              type="text" 
              placeholder="Filter by name, ID or email..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full bg-slate-900/50 border border-slate-800 rounded-2xl py-4 pl-12 pr-12 text-white focus:ring-1 focus:ring-emerald-500 outline-none transition-all placeholder-slate-600"
            />
            {search && (
              <button 
                onClick={() => setSearch('')}
                className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-500 hover:text-white transition-colors"
              >
                <i className="fas fa-circle-xmark"></i>
              </button>
            )}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredFriends.map((friend) => (
              <div 
                key={friend.id} 
                onClick={() => { setSelectedFriend(friend); setIsChatOpen(false); }}
                className="glass p-6 rounded-[32px] border border-slate-800 relative group overflow-hidden hover:border-emerald-500/50 transition-all cursor-pointer transform hover:-translate-y-1"
              >
                <div className="absolute top-0 right-0 w-24 h-24 bg-emerald-600/5 rounded-full -mr-12 -mt-12 blur-2xl"></div>
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center space-x-3">
                    <div className="relative">
                      <img src={friend.avatar} alt={friend.name} className="w-12 h-12 rounded-xl bg-slate-800 p-0.5 border border-slate-700 shadow-xl" />
                      <div className="absolute -bottom-1 -right-1 w-3 h-3 bg-emerald-500 rounded-full border border-slate-950"></div>
                    </div>
                    <div className="min-w-0">
                      <h3 className="font-black text-inherit uppercase text-xs tracking-wider truncate">{friend.name}</h3>
                      <p className="text-[8px] opacity-60 font-black text-emerald-500 uppercase tracking-widest truncate">{friend.pjId}</p>
                    </div>
                  </div>
                </div>
                
                <div className="flex items-center justify-between text-[9px] font-black uppercase tracking-widest opacity-50 mb-4">
                   <span>Goal Success</span>
                   <span className="text-emerald-400">{getFriendStats(friend.name).consistency}%</span>
                </div>
                <div className="w-full bg-slate-800 h-1 rounded-full overflow-hidden">
                   <div 
                    className="bg-emerald-500 h-full rounded-full transition-all duration-1000" 
                    style={{ width: `${getFriendStats(friend.name).consistency}%` }}
                   ></div>
                </div>
              </div>
            ))}
            
            {friends.length > 0 && filteredFriends.length === 0 && (
              <div className="col-span-full py-20 text-center glass rounded-[40px] border-2 border-dashed border-slate-800">
                <p className="text-slate-500 font-bold uppercase tracking-widest text-[10px]">No matches found for "{search}"</p>
                <button onClick={() => setSearch('')} className="mt-4 text-emerald-500 font-black uppercase text-[10px] tracking-widest hover:underline">Clear search</button>
              </div>
            )}

            {friends.length === 0 && (
              <div className="col-span-full py-20 text-center glass rounded-[40px] border border-dashed border-slate-800">
                <i className="fas fa-user-friends text-4xl text-slate-800 mb-4"></i>
                <p className="text-slate-500 font-bold uppercase tracking-widest text-[10px]">Your social network is empty</p>
                <button onClick={() => setShowAdd(true)} className="mt-4 bg-emerald-600 text-white px-6 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest hover:bg-emerald-500 transition-all">Add Your First Friend</button>
              </div>
            )}
          </div>
        </>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div className="space-y-4">
            <h2 className="text-[10px] font-black text-slate-500 uppercase tracking-[0.3em] ml-2">Incoming Requests</h2>
            {incomingRequests.map(req => (
              <div key={req.id} className="glass p-6 rounded-[32px] border border-slate-800 flex items-center justify-between group hover:border-emerald-500/20 transition-all">
                <div className="flex items-center space-x-4">
                  <div className="w-12 h-12 bg-emerald-600/20 rounded-2xl flex items-center justify-center text-emerald-400 border border-emerald-500/10">
                    <i className="fas fa-hand-sparkles text-lg"></i>
                  </div>
                  <div>
                    <p className="font-black text-inherit text-xs uppercase tracking-wider">{req.senderName}</p>
                    <p className="text-[8px] font-black text-emerald-500 uppercase tracking-widest">{req.senderPjId}</p>
                  </div>
                </div>
                <div className="flex items-center space-x-2">
                  <button 
                    onClick={() => handleAcceptRequest(req)}
                    className="w-10 h-10 bg-emerald-600 text-white rounded-xl flex items-center justify-center shadow-lg shadow-emerald-500/20 active:scale-90 transition-transform"
                  >
                    <i className="fas fa-check"></i>
                  </button>
                  <button 
                    onClick={() => handleDeclineRequest(req.id)}
                    className="w-10 h-10 bg-slate-800 text-rose-400 rounded-xl flex items-center justify-center hover:bg-rose-900/20 transition-all active:scale-90"
                  >
                    <i className="fas fa-times"></i>
                  </button>
                </div>
              </div>
            ))}
            {incomingRequests.length === 0 && (
               <div className="py-12 text-center opacity-30">
                 <p className="text-[10px] font-black uppercase tracking-widest italic">No pending invitations</p>
               </div>
            )}
          </div>

          <div className="space-y-4">
            <h2 className="text-[10px] font-black text-slate-500 uppercase tracking-[0.3em] ml-2">Sent Requests</h2>
            {outgoingRequests.map(req => (
              <div key={req.id} className="glass p-6 rounded-[32px] border border-slate-800 flex items-center justify-between bg-slate-900/20">
                <div className="flex items-center space-x-4">
                  <div className="w-12 h-12 bg-slate-800 rounded-2xl flex items-center justify-center text-slate-500">
                    <i className="fas fa-paper-plane text-sm"></i>
                  </div>
                  <div>
                    <p className="font-black opacity-50 text-xs uppercase tracking-wider">{req.receiverEmail}</p>
                    <p className="text-[10px] opacity-30 font-medium italic">Awaiting response...</p>
                  </div>
                </div>
                <button 
                  onClick={() => handleDeclineRequest(req.id)}
                  className="text-[10px] font-black text-slate-600 hover:text-rose-400 transition-colors uppercase"
                >
                  Cancel
                </button>
              </div>
            ))}
             {outgoingRequests.length === 0 && (
               <div className="py-12 text-center opacity-30">
                 <p className="text-[10px] font-black uppercase tracking-widest italic">No sent requests</p>
               </div>
            )}
          </div>
        </div>
      )}

      {selectedFriend && (
        <div className="fixed inset-0 bg-slate-950/95 backdrop-blur-xl z-[60] flex items-center justify-center p-4 overflow-y-auto">
          <div className="w-full max-w-4xl glass rounded-[48px] border border-slate-800 shadow-2xl overflow-hidden animate-in zoom-in duration-300 relative">
            <div className="absolute top-0 left-0 w-full h-32 bg-gradient-to-b from-emerald-600/20 to-transparent"></div>
            
            <button 
              onClick={() => { setSelectedFriend(null); setIsChatOpen(false); }}
              className="absolute top-8 right-8 w-12 h-12 bg-slate-900 border border-slate-700 rounded-full flex items-center justify-center text-white hover:bg-emerald-600 transition-all z-10 shadow-xl"
            >
              <i className="fas fa-times text-lg"></i>
            </button>

            <div className="grid grid-cols-1 lg:grid-cols-12 h-full min-h-[500px]">
              <div className="lg:col-span-4 p-8 border-r border-slate-800 bg-slate-900/30">
                <div className="flex flex-col items-center text-center">
                  <div className="relative mb-6">
                    <div className="w-32 h-32 rounded-[40px] border-4 border-emerald-600/30 p-1 shadow-2xl bg-slate-900">
                      <img src={selectedFriend.avatar} alt={selectedFriend.name} className="w-full h-full object-cover rounded-[36px]" />
                    </div>
                    <div className="absolute -bottom-2 -right-2 bg-emerald-600 px-3 py-1 rounded-full border-4 border-slate-950 text-[8px] font-black text-white uppercase tracking-widest">
                      {getFriendStats(selectedFriend.name).archetype}
                    </div>
                  </div>
                  <h2 className="text-3xl font-black text-inherit tracking-tighter mb-1 uppercase">{selectedFriend.name}</h2>
                  <p className="text-emerald-500 font-black text-[10px] uppercase tracking-[0.3em] mb-2">{selectedFriend.pjId}</p>
                  <p className="opacity-40 font-bold text-[10px] uppercase tracking-widest mb-8">{selectedFriend.email}</p>

                  <div className="bg-slate-950/60 p-4 rounded-3xl border border-slate-800 w-full mb-6 text-left">
                     <div className="flex items-center justify-between mb-4">
                       <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Live Data Access</p>
                       <button 
                        onClick={(e) => { e.stopPropagation(); togglePermission(selectedFriend.id); }}
                        className={`w-10 h-6 rounded-full relative transition-all ${permissions[selectedFriend.id] ? 'bg-emerald-600' : 'bg-slate-800'}`}
                       >
                         <div className={`absolute top-1 w-4 h-4 rounded-full bg-white transition-all ${permissions[selectedFriend.id] ? 'left-5' : 'left-1'}`}></div>
                       </button>
                     </div>
                     <p className="text-[8px] text-slate-600 font-bold uppercase leading-relaxed">
                       When active, {selectedFriend.name.split(' ')[0]} can see your real-time budget utilization and savings scores.
                     </p>
                  </div>

                  <div className="w-full mt-auto space-y-3">
                    <button 
                      onClick={() => setIsChatOpen(!isChatOpen)}
                      className={`w-full font-black uppercase text-[10px] tracking-[0.2em] py-4 rounded-[20px] transition-all flex items-center justify-center space-x-3 ${isChatOpen ? 'bg-indigo-600 text-white' : 'bg-slate-800 text-slate-300 hover:text-white'}`}
                    >
                      <i className="fas fa-comment-dots text-sm"></i>
                      <span>{isChatOpen ? 'View Profile' : 'Secure Chat'}</span>
                    </button>
                    <button 
                      onClick={() => handleShareFriendProfile(selectedFriend)}
                      className="w-full bg-indigo-600/10 hover:bg-indigo-600 text-indigo-400 hover:text-white border border-indigo-500/20 font-black uppercase text-[10px] tracking-[0.2em] py-4 rounded-[20px] transition-all active:scale-95 flex items-center justify-center space-x-3"
                    >
                      <i className="fas fa-share-nodes text-sm"></i>
                      <span>Share Profile</span>
                    </button>
                    <button 
                      onClick={() => onNotify(`Nudge sent to ${selectedFriend.name.split(' ')[0]}`, 'success')}
                      className="w-full bg-emerald-600 hover:bg-emerald-500 text-white font-black uppercase text-[10px] tracking-[0.2em] py-4 rounded-[20px] shadow-xl shadow-emerald-500/20 transition-all active:scale-95 flex items-center justify-center space-x-3"
                    >
                      <i className="fas fa-bell text-sm"></i>
                      <span>Send Nudge</span>
                    </button>
                    <button 
                      onClick={() => setShowDeleteConfirm(selectedFriend.id)}
                      className="w-full py-4 bg-rose-600/10 hover:bg-rose-600 text-rose-500 hover:text-white border border-rose-500/20 rounded-[20px] transition-all text-[10px] font-black uppercase tracking-widest"
                    >
                      Unfriend
                    </button>
                  </div>
                </div>
              </div>

              <div className="lg:col-span-8 p-8 h-[600px] overflow-hidden flex flex-col">
                {isChatOpen ? (
                  <div className="flex-1 flex flex-col bg-slate-950/40 rounded-[32px] border border-slate-800 overflow-hidden">
                    <div className="p-5 border-b border-slate-800 bg-slate-900/60 flex items-center justify-between">
                       <div className="flex items-center space-x-3">
                         <img src={selectedFriend.avatar} alt={selectedFriend.name} className="w-8 h-8 rounded-lg bg-slate-800 border border-slate-700 p-0.5" />
                         <div>
                            <p className="text-[10px] font-black text-white uppercase tracking-widest">Chat with {selectedFriend.name.split(' ')[0]}</p>
                            <div className="flex items-center space-x-1">
                              <div className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-pulse"></div>
                              <span className="text-[8px] font-black text-emerald-500 uppercase tracking-widest">End-to-End Encrypted</span>
                            </div>
                         </div>
                       </div>
                       <i className="fas fa-shield-halved text-[10px] text-emerald-500/50"></i>
                    </div>

                    <div ref={chatScrollRef} className="flex-1 overflow-y-auto p-6 space-y-4 scrollbar-hide">
                      {currentFriendMessages.length === 0 && (
                        <div className="h-full flex flex-col items-center justify-center text-center opacity-30">
                          <i className="fas fa-comments text-4xl mb-4"></i>
                          <p className="text-[10px] font-black uppercase tracking-widest">Start a private conversation</p>
                          <p className="text-[8px] font-black uppercase tracking-[0.2em] mt-2">Only you and {selectedFriend.name.split(' ')[0]} can see this</p>
                        </div>
                      )}
                      {currentFriendMessages.map(m => (
                        <div key={m.id} className={`flex ${m.senderId === user.id ? 'justify-end' : 'justify-start'}`}>
                          <div className={`max-w-[80%] p-4 rounded-3xl ${
                            m.senderId === user.id 
                              ? 'bg-emerald-600 text-white rounded-tr-none' 
                              : 'bg-slate-800 text-slate-100 rounded-tl-none border border-slate-700'
                          }`}>
                            <p className="text-sm font-medium">{m.text}</p>
                            <p className="text-[8px] mt-1 opacity-50 uppercase font-black text-right">{m.timestamp}</p>
                          </div>
                        </div>
                      ))}
                    </div>

                    <div className="p-6 bg-slate-900/80 border-t border-slate-800">
                       <div className="flex space-x-3">
                         <div className="flex-1 relative">
                            <input 
                              type="text"
                              value={chatInput}
                              onChange={(e) => setChatInput(e.target.value)}
                              onKeyDown={(e) => e.key === 'Enter' && handleSendMessage()}
                              placeholder="Type a secure message..."
                              className="w-full bg-slate-950 border border-slate-800 rounded-2xl px-5 py-4 text-white text-xs focus:ring-1 focus:ring-emerald-500 outline-none transition-all placeholder-slate-600 pr-12"
                            />
                            <div className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-700">
                               <i className="fas fa-paperclip text-sm"></i>
                            </div>
                         </div>
                         <button 
                          onClick={handleSendMessage}
                          disabled={!chatInput.trim()}
                          className="px-6 h-12 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-30 text-white rounded-2xl flex items-center justify-center transition-all shadow-xl shadow-emerald-500/20 active:scale-95 group"
                         >
                           <span className="text-[10px] font-black uppercase tracking-widest mr-2 hidden sm:block">Send</span>
                           <i className="fas fa-paper-plane text-xs group-hover:translate-x-1 group-hover:-translate-y-1 transition-transform"></i>
                         </button>
                       </div>
                    </div>
                  </div>
                ) : (
                  <div className="space-y-8 animate-in fade-in duration-300">
                    <div>
                       <h3 className="text-xs font-black text-inherit uppercase tracking-[0.3em] mb-2 flex items-center">
                         <i className="fas fa-chart-column text-emerald-400 mr-3"></i>
                         Peer Comparison Analytics
                       </h3>
                       <p className="opacity-40 text-[10px] uppercase font-bold tracking-widest mb-6">Compare category spending with {selectedFriend.name.split(' ')[0]}</p>
                       
                       <div className="h-[300px] w-full bg-slate-900/50 rounded-[32px] border border-slate-800 p-4">
                         <ResponsiveContainer width="100%" height="100%">
                           <BarChart data={getComparisonData(selectedFriend.name)}>
                             <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" vertical={false} />
                             <XAxis 
                              dataKey="name" 
                              stroke="#475569" 
                              fontSize={10} 
                              tickLine={false} 
                              axisLine={false} 
                              // Fixed: Removed textTransform from tick object and used tickFormatter instead
                              tick={{fontWeight: '900'}}
                              tickFormatter={(value) => value.toUpperCase()}
                             />
                             <YAxis 
                              stroke="#475569" 
                              fontSize={10} 
                              tickLine={false} 
                              axisLine={false} 
                              tickFormatter={(value) => `₹${value}`}
                             />
                             <Tooltip 
                               contentStyle={{ backgroundColor: '#0f172a', border: '1px solid #1e293b', borderRadius: '12px' }}
                               itemStyle={{ fontSize: '12px', fontWeight: 'bold' }}
                             />
                             <Legend 
                               verticalAlign="top" 
                               align="right" 
                               wrapperStyle={{ fontSize: '10px', fontWeight: 'bold', textTransform: 'uppercase', marginBottom: '10px' }}
                             />
                             <Bar dataKey="Me" fill="#10b981" radius={[4, 4, 0, 0]} />
                             <Bar dataKey={selectedFriend.name.split(' ')[0]} fill="#3b82f6" radius={[4, 4, 0, 0]} />
                           </BarChart>
                         </ResponsiveContainer>
                       </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                       <div className="glass p-5 rounded-3xl border border-slate-800">
                          <p className="text-[8px] font-black text-slate-500 uppercase tracking-widest mb-1">Consistency</p>
                          <p className="text-xl font-black text-emerald-400">{getFriendStats(selectedFriend.name).consistency}%</p>
                       </div>
                       <div className="glass p-5 rounded-3xl border border-slate-800">
                          <p className="text-[8px] font-black text-slate-500 uppercase tracking-widest mb-1">Estimated Savings</p>
                          <p className="text-xl font-black text-white">₹{getFriendStats(selectedFriend.name).savings.toLocaleString()}</p>
                       </div>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {showDeleteConfirm && (
        <div className="fixed inset-0 bg-slate-950/90 backdrop-blur-md z-[100] flex items-center justify-center p-4">
          <div className="glass w-full max-w-sm rounded-[32px] p-8 border border-rose-500/20 animate-in fade-in zoom-in duration-200">
            <h3 className="text-xl font-black text-inherit text-center mb-2 uppercase tracking-tighter">Remove Connection?</h3>
            <div className="flex flex-col space-y-3 pt-6">
              <button 
                onClick={() => removeFriend(showDeleteConfirm)}
                className="w-full py-4 bg-rose-600 hover:bg-rose-500 text-white font-black uppercase text-[10px] tracking-widest rounded-2xl transition-all"
              >
                Yes, Remove Connection
              </button>
              <button 
                onClick={() => setShowDeleteConfirm(null)}
                className="w-full py-4 bg-slate-800 text-slate-400 font-black uppercase text-[10px] tracking-widest rounded-2xl hover:text-white transition-all"
              >
                No, Keep
              </button>
            </div>
          </div>
        </div>
      )}

      {showAdd && (
        <div className="fixed inset-0 bg-slate-950/90 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="glass w-full max-w-md rounded-[40px] p-8 border border-slate-800 animate-in fade-in zoom-in duration-200">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-black text-inherit tracking-tighter uppercase">Add Connection</h2>
              <button onClick={() => setShowAdd(false)} className="text-slate-500 hover:text-white">
                <i className="fas fa-times"></i>
              </button>
            </div>

            <div className="flex bg-slate-900 p-1 rounded-xl mb-6 border border-slate-800">
               <button 
                onClick={() => setSearchMode('id')}
                className={`flex-1 py-2 text-[9px] font-black uppercase tracking-widest rounded-lg transition-all ${searchMode === 'id' ? 'bg-emerald-600 text-white' : 'text-slate-500'}`}
               >
                 By PJ-ID
               </button>
               <button 
                onClick={() => setSearchMode('name')}
                className={`flex-1 py-2 text-[9px] font-black uppercase tracking-widest rounded-lg transition-all ${searchMode === 'name' ? 'bg-emerald-600 text-white' : 'text-slate-500'}`}
               >
                 By Email/Name
               </button>
            </div>

            <form onSubmit={handleSendRequest} className="space-y-4">
              {searchMode === 'id' ? (
                <div>
                  <label className="block text-slate-500 text-[10px] font-black uppercase tracking-widest mb-1.5 ml-2">Unique PJ-ID</label>
                  <div className="relative">
                    <span className="absolute left-5 top-1/2 -translate-y-1/2 text-emerald-500 font-black text-[10px] pointer-events-none">PJ-</span>
                    <input 
                      type="text" 
                      required
                      placeholder="XXXXXXX"
                      value={newFriend.pjId.replace('PJ-', '')}
                      onChange={(e) => setNewFriend({ ...newFriend, pjId: `PJ-${e.target.value.toUpperCase().replace(/[^0-9A-Z]/g, '')}` })}
                      className="w-full bg-slate-950 border border-slate-800 rounded-2xl pl-12 pr-5 py-4 text-white focus:ring-1 focus:ring-emerald-500 outline-none transition-all font-mono"
                    />
                  </div>
                  <p className="mt-2 text-[8px] text-slate-500 uppercase font-bold tracking-widest ml-2">Example: PJ-8829103</p>
                </div>
              ) : (
                <>
                  <div>
                    <label className="block text-slate-500 text-[10px] font-black uppercase tracking-widest mb-1.5 ml-2">Friend's Name</label>
                    <input 
                      type="text" 
                      required
                      value={newFriend.name}
                      onChange={(e) => setNewFriend({ ...newFriend, name: e.target.value })}
                      className="w-full bg-slate-950 border border-slate-800 rounded-2xl px-5 py-4 text-white focus:ring-1 focus:ring-emerald-500 outline-none transition-all"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-500 text-[10px] font-black uppercase tracking-widest mb-1.5 ml-2">Email Address</label>
                    <input 
                      type="email" 
                      required
                      value={newFriend.email}
                      onChange={(e) => setNewFriend({ ...newFriend, email: e.target.value })}
                      className="w-full bg-slate-950 border border-slate-800 rounded-2xl px-5 py-4 text-white focus:ring-1 focus:ring-emerald-500 outline-none transition-all"
                    />
                  </div>
                </>
              )}
              <div className="flex space-x-3 pt-6">
                <button type="button" onClick={() => setShowAdd(false)} className="flex-1 py-4 text-slate-500 font-black uppercase text-[10px] tracking-widest">Cancel</button>
                <button type="submit" className="flex-1 bg-emerald-600 hover:bg-emerald-500 text-white font-black uppercase text-[10px] tracking-widest py-4 rounded-2xl transition-all shadow-xl shadow-emerald-500/20">Send Request</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default Friends;
