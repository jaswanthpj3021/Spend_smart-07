
import React, { useState } from 'react';
import { User } from '../types';

interface LoginProps {
  onLogin: (user: User) => void;
  onSwitch: () => void;
}

const Login: React.FC<LoginProps> = ({ onLogin, onSwitch }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isForgotPassword, setIsForgotPassword] = useState(false);
  const [resetEmail, setResetEmail] = useState('');
  const [resetSent, setResetSent] = useState(false);

  const generateDeterministicPjId = (email: string) => {
    let hash = 0;
    for (let i = 0; i < email.length; i++) {
      hash = ((hash << 5) - hash) + email.charCodeAt(i);
      hash |= 0;
    }
    const absHash = Math.abs(hash);
    const digits = (absHash % 9000000) + 1000000;
    return `PJ-${digits}`;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onLogin({
      id: Math.abs(email.length * 7).toString(),
      pjId: generateDeterministicPjId(email),
      name: email.split('@')[0].charAt(0).toUpperCase() + email.split('@')[0].slice(1),
      email: email,
      currency: 'INR',
      totalBudget: 0,
      memberSince: new Date().toISOString(),
      settings: {
        friendRequestNotifications: true
      }
    });
  };

  const handleResetRequest = (e: React.FormEvent) => {
    e.preventDefault();
    setResetSent(true);
    // Simulation: would normally call an API
  };

  if (isForgotPassword) {
    return (
      <div className="min-h-screen bg-slate-950 flex items-center justify-center p-4 relative overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-full opacity-10 pointer-events-none">
          <div className="absolute top-10 left-10 w-96 h-96 bg-emerald-600 rounded-full blur-[150px] animate-pulse"></div>
        </div>

        <div className="w-full max-w-md glass p-10 rounded-[40px] shadow-2xl z-10 border border-slate-800 backdrop-blur-3xl animate-in zoom-in duration-300">
          <button 
            onClick={() => { setIsForgotPassword(false); setResetSent(false); }}
            className="mb-8 text-slate-500 hover:text-white flex items-center space-x-2 text-[10px] font-black uppercase tracking-widest"
          >
            <i className="fas fa-arrow-left"></i>
            <span>Back to Login</span>
          </button>

          <div className="text-center mb-10">
            <div className="w-16 h-16 bg-emerald-600/20 rounded-2xl flex items-center justify-center mx-auto mb-6 text-emerald-400">
              <i className="fas fa-shield-keyhole text-3xl"></i>
            </div>
            <h1 className="text-2xl font-black text-white tracking-tighter mb-2 uppercase">Vault Recovery</h1>
            <p className="text-slate-500 font-medium text-xs">Enter your primary alias to reset credentials</p>
          </div>

          {!resetSent ? (
            <form onSubmit={handleResetRequest} className="space-y-6">
              <div className="relative">
                <i className="fas fa-at absolute left-5 top-1/2 -translate-y-1/2 text-slate-600"></i>
                <input 
                  type="email" 
                  required
                  value={resetEmail}
                  onChange={(e) => setResetEmail(e.target.value)}
                  className="w-full bg-slate-900/80 border border-slate-800 rounded-2xl py-4 pl-14 pr-4 text-white placeholder-slate-600 focus:outline-none focus:ring-1 focus:ring-emerald-500/50 transition-all font-medium text-sm"
                  placeholder="Registered Email"
                />
              </div>
              <button 
                type="submit"
                className="w-full bg-emerald-600 hover:bg-emerald-500 text-white font-black uppercase tracking-widest py-4 rounded-2xl shadow-xl shadow-emerald-500/20 transition-all active:scale-95"
              >
                Send Recovery Pulse
              </button>
            </form>
          ) : (
            <div className="text-center py-6 animate-in fade-in slide-in-from-bottom-2">
              <div className="w-12 h-12 bg-emerald-500/10 rounded-full flex items-center justify-center mx-auto mb-4 text-emerald-400">
                <i className="fas fa-check"></i>
              </div>
              <p className="text-white font-bold text-sm mb-2">Pulse Transmitted!</p>
              <p className="text-slate-500 text-xs mb-8">Check your inbox for the secondary vault bypass key.</p>
              <button 
                onClick={() => setIsForgotPassword(false)}
                className="text-emerald-400 font-black uppercase text-[10px] tracking-widest hover:underline"
              >
                Return to Login
              </button>
            </div>
          )}
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-950 flex items-center justify-center p-4 relative overflow-hidden">
      <div className="absolute top-0 left-0 w-full h-full opacity-10 pointer-events-none">
        <div className="absolute top-10 left-10 w-96 h-96 bg-emerald-600 rounded-full blur-[150px] animate-pulse"></div>
        <div className="absolute bottom-10 right-10 w-80 h-80 bg-blue-600 rounded-full blur-[150px]"></div>
      </div>

      <div className="w-full max-w-md glass p-10 rounded-[40px] shadow-2xl z-10 border border-slate-800 backdrop-blur-3xl">
        <div className="text-center mb-12">
          <div className="w-20 h-20 bg-emerald-600 rounded-3xl flex items-center justify-center mx-auto mb-6 shadow-2xl shadow-emerald-500/30 rotate-3 transition-transform hover:rotate-0">
            <i className="fas fa-indian-rupee-sign text-white text-4xl"></i>
          </div>
          <h1 className="text-4xl font-black text-white tracking-tighter mb-2">Spend Smart</h1>
          <p className="text-slate-500 font-medium uppercase text-[10px] tracking-[0.2em]">Master your financial future</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-5">
          <div>
            <div className="relative">
              <i className="fas fa-at absolute left-5 top-1/2 -translate-y-1/2 text-slate-600"></i>
              <input 
                type="email" 
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full bg-slate-900/80 border border-slate-800 rounded-2xl py-4 pl-14 pr-4 text-white placeholder-slate-600 focus:outline-none focus:ring-1 focus:ring-emerald-500/50 transition-all font-medium"
                placeholder="Email Address"
              />
            </div>
          </div>

          <div>
            <div className="relative">
              <i className="fas fa-fingerprint absolute left-5 top-1/2 -translate-y-1/2 text-slate-600"></i>
              <input 
                type="password" 
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full bg-slate-900/80 border border-slate-800 rounded-2xl py-4 pl-14 pr-4 text-white placeholder-slate-600 focus:outline-none focus:ring-1 focus:ring-emerald-500/50 transition-all font-medium"
                placeholder="Secret Password"
              />
            </div>
            <div className="text-right mt-3">
              <button 
                type="button" 
                onClick={() => setIsForgotPassword(true)}
                className="text-[10px] font-black uppercase text-emerald-500 tracking-widest hover:text-emerald-400"
              >
                Forgot Key?
              </button>
            </div>
          </div>

          <button 
            type="submit"
            className="w-full bg-emerald-600 hover:bg-emerald-500 text-white font-black uppercase tracking-widest py-5 rounded-2xl shadow-xl shadow-emerald-500/20 transform transition-all active:scale-95 mt-4"
          >
            Access Vault
          </button>
        </form>

        <div className="mt-10 text-center">
          <p className="text-slate-500 text-sm font-medium">
            New to Spend Smart? 
            <button onClick={onSwitch} className="ml-2 text-emerald-400 font-bold hover:underline">Join Now</button>
          </p>
        </div>
      </div>
    </div>
  );
};

export default Login;
