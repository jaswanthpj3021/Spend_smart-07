import React from 'react';
import { User } from '../types';

interface SidebarProps {
  currentView: string;
  setView: (view: any) => void;
  user: User;
  onLogout: () => void;
  isOpen?: boolean;
}

const Sidebar: React.FC<SidebarProps> = ({ currentView, setView, user, onLogout, isOpen }) => {
  const menuItems = [
    { id: 'dashboard', label: 'Dashboard', icon: 'fa-table-columns' },
    { id: 'transactions', label: 'Expenses', icon: 'fa-indian-rupee-sign' },
    { id: 'budget', label: 'Budget Plan', icon: 'fa-vault' },
    { id: 'friends', label: 'Friends', icon: 'fa-user-group' },
    { id: 'notes', label: 'Receipt Notes', icon: 'fa-sticky-note' },
    { id: 'chat', label: 'Spend Smart AI', icon: 'fa-comments' },
    { id: 'profile', label: 'Account', icon: 'fa-circle-user' },
  ];

  return (
    <aside className={`fixed md:static inset-y-0 left-0 w-64 glass border-r border-slate-800 flex flex-col z-[60] transition-transform duration-300 ease-in-out ${
      isOpen ? 'translate-x-0' : '-translate-x-full md:translate-x-0'
    }`}>
      <div className="p-6">
        <div className="flex items-center space-x-3 mb-8">
          <div className="w-10 h-10 bg-teal-500 rounded-xl flex items-center justify-center shadow-lg shadow-teal-500/30">
            <i className="fas fa-indian-rupee-sign text-white text-xl"></i>
          </div>
          <span className="text-xl font-black tracking-tight text-white uppercase italic">Spend Smart</span>
        </div>

        <nav className="space-y-1">
          {menuItems.map((item) => (
            <button
              key={item.id}
              onClick={() => setView(item.id)}
              className={`w-full flex items-center space-x-3 px-4 py-3 rounded-xl transition-all duration-200 ${
                currentView === item.id 
                  ? 'bg-teal-500/10 text-teal-400 border border-teal-500/20' 
                  : 'text-slate-400 hover:text-white hover:bg-slate-800/50'
              }`}
            >
              <i className={`fas ${item.icon} w-5`}></i>
              <span className="font-bold text-xs uppercase tracking-widest">{item.label}</span>
            </button>
          ))}
        </nav>
      </div>

      <div className="mt-auto p-6 border-t border-slate-800">
        <div className="flex items-center space-x-3 mb-4">
          {user.avatar ? (
            <img 
              src={user.avatar} 
              alt="Avatar" 
              className="w-10 h-10 rounded-full border-2 border-slate-800 object-cover"
            />
          ) : (
            <div className="w-10 h-10 rounded-full bg-teal-500 flex items-center justify-center border-2 border-teal-500/50 shadow-lg">
              <i className="fas fa-user text-white text-sm"></i>
            </div>
          )}
          <div className="truncate">
            <p className="text-sm font-semibold text-white truncate">{user.name}</p>
            <div className="flex items-center space-x-1">
              <div className="w-1 h-1 bg-teal-400 rounded-full animate-pulse"></div>
              <p className="text-[9px] text-slate-500 truncate uppercase font-black">Live Vault Access</p>
            </div>
          </div>
        </div>
        <button 
          onClick={onLogout}
          className="w-full flex items-center justify-center space-x-2 px-4 py-3 bg-slate-800 hover:bg-red-900/20 hover:text-red-400 text-slate-400 rounded-xl transition-colors border border-slate-700"
        >
          <i className="fas fa-power-off text-xs"></i>
          <span className="text-[10px] font-black uppercase tracking-widest">Logout</span>
        </button>
      </div>
    </aside>
  );
};

export default Sidebar;