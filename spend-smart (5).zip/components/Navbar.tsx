import React, { useState } from 'react';
import { User, Theme } from '../types';

interface NavbarProps {
  user: User;
  setView: (view: any) => void;
  theme: Theme;
  setTheme: (theme: Theme) => void;
  toggleMobileMenu: () => void;
}

const Navbar: React.FC<NavbarProps> = ({ user, setView, theme, setTheme, toggleMobileMenu }) => {
  const [showNotifications, setShowNotifications] = useState(false);
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  const themes = Object.values(Theme);
  
  const cycleTheme = () => {
    const currentIndex = themes.indexOf(theme);
    const nextIndex = (currentIndex + 1) % themes.length;
    setTheme(themes[nextIndex]);
  };

  const getThemeIcon = () => {
    switch (theme) {
      case Theme.DARK: return 'fa-moon';
      case Theme.LIGHT: return 'fa-sun';
      case Theme.NEON: return 'fa-bolt-lightning';
      case Theme.CYBERPUNK: return 'fa-robot';
      case Theme.LUXURY: return 'fa-gem';
      case Theme.ATLANTIS: return 'fa-water';
      case Theme.MARS: return 'fa-fire';
      case Theme.LAVENDER: return 'fa-wand-sparkles';
      default: return 'fa-moon';
    }
  };

  const getAccentColor = () => {
    switch (theme) {
      case Theme.LUXURY: return 'text-[#d4af37]';
      case Theme.ATLANTIS: return 'text-[#2aa198]';
      case Theme.MARS: return 'text-[#ff4d4d]';
      case Theme.LAVENDER: return 'text-[#e0b0ff]';
      default: return 'text-teal-400';
    }
  };

  return (
    <header className="h-14 glass border-b border-slate-800 flex items-center justify-between px-4 z-40 sticky top-0">
      <div className="flex items-center space-x-3">
        <button 
          onClick={(e) => { e.stopPropagation(); toggleMobileMenu(); }} 
          className="md:hidden text-slate-400 p-2 hover:bg-slate-800 rounded-lg transition-colors"
        >
          <i className="fas fa-bars text-lg"></i>
        </button>
        <div className="flex items-center space-x-2">
          <div className="w-8 h-8 bg-teal-500 rounded-lg flex items-center justify-center shadow-md rotate-3">
            <i className="fas fa-indian-rupee-sign text-white text-sm"></i>
          </div>
          <span className="font-black text-inherit tracking-tighter text-lg hidden sm:block">Spend Smart</span>
        </div>
      </div>
      
      <div className="flex items-center space-x-2">
        <div className="flex items-center bg-slate-900/40 border border-slate-800 rounded-xl p-1 transition-all">
          <div className={`relative flex items-center transition-all duration-500 ease-in-out ${isSearchOpen ? 'w-32 sm:w-60' : 'w-0 overflow-hidden'}`}>
            <input 
              type="text"
              placeholder="Search..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-transparent text-inherit text-[10px] placeholder-slate-600 focus:outline-none px-2"
              autoFocus={isSearchOpen}
            />
          </div>

          <div className="flex items-center">
            <button 
              onClick={cycleTheme}
              className={`w-7 h-7 flex items-center justify-center rounded-lg transition-all hover:bg-slate-800 ${getAccentColor()}`}
              title="Change Theme"
            >
              <i className={`fas ${getThemeIcon()} text-xs`}></i>
            </button>

            <div className="w-px h-5 bg-slate-800 mx-1"></div>

            <button 
              onClick={() => setShowNotifications(!showNotifications)}
              className="w-7 h-7 flex items-center justify-center rounded-lg transition-all relative text-slate-400 hover:text-white"
            >
              <i className="fas fa-bell text-xs"></i>
              <span className="absolute top-1.5 right-1.5 w-1 h-1 bg-teal-400 rounded-full border border-slate-950"></span>
            </button>

            <div className="w-px h-5 bg-slate-800 mx-1"></div>

            <button 
              onClick={() => setIsSearchOpen(!isSearchOpen)}
              className={`w-7 h-7 flex items-center justify-center rounded-lg transition-all ${isSearchOpen ? 'bg-slate-800 text-teal-400' : 'text-slate-400 hover:text-white'}`}
            >
              <i className={`fas ${isSearchOpen ? 'fa-xmark' : 'fa-search'} text-xs`}></i>
            </button>
          </div>
        </div>

        <button 
          onClick={() => setView('profile')}
          className="flex items-center space-x-2 p-0.5 pr-2 rounded-xl bg-slate-900 border border-slate-800 hover:border-teal-500/30 transition-all group shrink-0"
        >
          <div className="w-7 h-7 rounded-lg bg-slate-700 border border-slate-600 flex items-center justify-center overflow-hidden">
            {user.avatar ? (
              <img src={user.avatar} alt="Profile" className="w-full h-full object-cover" />
            ) : (
              <div className="w-full h-full bg-teal-500 flex items-center justify-center">
                <i className="fas fa-user text-white text-[10px]"></i>
              </div>
            )}
          </div>
          <p className="text-[10px] font-bold text-white hidden lg:block">{user.name}</p>
        </button>
      </div>
    </header>
  );
};

export default Navbar;