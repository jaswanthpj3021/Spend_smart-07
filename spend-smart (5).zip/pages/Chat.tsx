import React, { useState, useRef, useEffect, useCallback } from 'react';
/* Modality is imported from @google/genai, not ../types */
import { User, ChatMessage, Friend } from '../types';
import { chatWithAI } from '../services/geminiService';
/* Consolidate @google/genai imports and include Modality and LiveServerMessage */
import { GoogleGenAI, Modality, LiveServerMessage } from '@google/genai';

// Helper functions for Live API
function encode(bytes: Uint8Array) {
  let binary = '';
  const len = bytes.byteLength;
  for (let i = 0; i < len; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary);
}

function decode(base64: string) {
  const binaryString = atob(base64);
  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes;
}

async function decodeAudioData(
  data: Uint8Array,
  ctx: AudioContext,
  sampleRate: number,
  numChannels: number,
): Promise<AudioBuffer> {
  const dataInt16 = new Int16Array(data.buffer);
  const frameCount = dataInt16.length / numChannels;
  const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);

  for (let channel = 0; channel < numChannels; channel++) {
    const channelData = buffer.getChannelData(channel);
    for (let i = 0; i < frameCount; i++) {
      channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
    }
  }
  return buffer;
}

const Chat: React.FC<{ user: User }> = ({ user }) => {
  const [activeTab, setActiveTab] = useState<'ai' | 'community'>('ai');
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [isVoiceActive, setIsVoiceActive] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);
  
  // Refs for Live API
  const audioContextRef = useRef<AudioContext | null>(null);
  const sessionRef = useRef<any>(null);
  const nextStartTimeRef = useRef(0);
  const sourcesRef = useRef<Set<AudioBufferSourceNode>>(new Set());

  const [friends] = useState<Friend[]>(() => {
    const saved = localStorage.getItem('smartspend_friends');
    return saved ? JSON.parse(saved) : [];
  });

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isTyping]);

  const stopVoiceMode = useCallback(() => {
    if (sessionRef.current) {
      sessionRef.current.close();
      sessionRef.current = null;
    }
    if (audioContextRef.current) {
      audioContextRef.current.close();
      audioContextRef.current = null;
    }
    sourcesRef.current.forEach(s => s.stop());
    sourcesRef.current.clear();
    setIsVoiceActive(false);
  }, []);

  const startVoiceMode = async () => {
    try {
      setIsVoiceActive(true);
      /* Create new GoogleGenAI instance right before making an API call */
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      
      const inputCtx = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
      const outputCtx = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
      audioContextRef.current = outputCtx;

      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      
      const sessionPromise = ai.live.connect({
        model: 'gemini-2.5-flash-native-audio-preview-12-2025',
        callbacks: {
          onopen: () => {
            const source = inputCtx.createMediaStreamSource(stream);
            const processor = inputCtx.createScriptProcessor(4096, 1, 1);
            processor.onaudioprocess = (e) => {
              const inputData = e.inputBuffer.getChannelData(0);
              const l = inputData.length;
              const int16 = new Int16Array(l);
              for (let i = 0; i < l; i++) {
                int16[i] = inputData[i] * 32768;
              }
              const pcmBlob = {
                data: encode(new Uint8Array(int16.buffer)),
                mimeType: 'audio/pcm;rate=16000',
              };
              /* Solely rely on sessionPromise resolves and then call session.sendRealtimeInput */
              sessionPromise.then(session => session.sendRealtimeInput({ media: pcmBlob }));
            };
            source.connect(processor);
            processor.connect(inputCtx.destination);
          },
          onmessage: async (message: LiveServerMessage) => {
            const audioData = message.serverContent?.modelTurn?.parts[0]?.inlineData?.data;
            if (audioData) {
              nextStartTimeRef.current = Math.max(nextStartTimeRef.current, outputCtx.currentTime);
              const buffer = await decodeAudioData(decode(audioData), outputCtx, 24000, 1);
              const source = outputCtx.createBufferSource();
              source.buffer = buffer;
              source.connect(outputCtx.destination);
              source.start(nextStartTimeRef.current);
              nextStartTimeRef.current += buffer.duration;
              sourcesRef.current.add(source);
              source.onended = () => sourcesRef.current.delete(source);
            }
            if (message.serverContent?.interrupted) {
              for (const source of sourcesRef.current.values()) {
                source.stop();
              }
              sourcesRef.current.clear();
              nextStartTimeRef.current = 0;
            }
          },
          onclose: () => setIsVoiceActive(false),
          onerror: (e) => {
            console.error(e);
            stopVoiceMode();
          }
        },
        config: {
          /* responseModalities must contain exactly one modality: Modality.AUDIO */
          responseModalities: [Modality.AUDIO],
          speechConfig: {
            voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Zephyr' } }
          },
          systemInstruction: "You are Spend Smart AI. Provide real-time financial advice in a friendly, encouraging way. You are speaking to the user directly."
        }
      });

      sessionRef.current = await sessionPromise;
    } catch (err) {
      console.error(err);
      setIsVoiceActive(false);
    }
  };

  const handleSend = async () => {
    if (!input.trim()) return;

    const userMsg: ChatMessage = {
      id: Date.now().toString(),
      sender: 'user',
      text: input,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setMessages([...messages, userMsg]);
    setInput('');

    if (activeTab === 'ai') {
      setIsTyping(true);
      const aiResponse = await chatWithAI(input, messages.slice(-5).map(m => ({
        role: m.sender === 'user' ? 'user' : 'model',
        parts: [{ text: m.text }]
      })));
      const aiMsg: ChatMessage = {
        id: (Date.now() + 1).toString(),
        sender: 'ai',
        text: aiResponse || "I didn't quite catch that.",
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };
      setMessages(prev => [...prev, aiMsg]);
      setIsTyping(false);
    } else {
      setTimeout(() => {
        const speaker = friends.length > 0 ? friends[Math.floor(Math.random() * friends.length)] : { name: 'SmartBot' };
        const communityMsg: ChatMessage = {
          id: (Date.now() + 1).toString(),
          sender: 'community',
          name: speaker.name,
          text: friends.length > 0 
            ? `I totally agree with you, ${user.name.split(' ')[0]}! Checking my daily budget has been a game changer.`
            : "Welcome to the community! Add friends to see their activity here.",
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
        };
        setMessages(prev => [...prev, communityMsg]);
      }, 1000);
    }
  };

  return (
    <div className="flex flex-col h-[calc(100vh-140px)] glass rounded-[40px] overflow-hidden border border-slate-800 shadow-2xl animate-in fade-in duration-500">
      <div className="p-5 border-b border-slate-800 flex items-center justify-between bg-slate-900/60 backdrop-blur-xl">
        <div className="flex space-x-2">
          <button 
            onClick={() => { setActiveTab('ai'); setMessages([]); stopVoiceMode(); }}
            className={`px-5 py-2.5 rounded-2xl text-xs font-black uppercase tracking-widest transition-all ${activeTab === 'ai' ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/20' : 'text-slate-500 hover:text-white hover:bg-slate-800'}`}
          >
            AI Assistant
          </button>
          <button 
            onClick={() => { setActiveTab('community'); setMessages([]); stopVoiceMode(); }}
            className={`px-5 py-2.5 rounded-2xl text-xs font-black uppercase tracking-widest transition-all ${activeTab === 'community' ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-600/20' : 'text-slate-500 hover:text-white hover:bg-slate-800'}`}
          >
            Community
          </button>
        </div>
        <div className="flex items-center space-x-4">
          {activeTab === 'ai' && (
            <button 
              onClick={isVoiceActive ? stopVoiceMode : startVoiceMode}
              className={`w-10 h-10 rounded-xl flex items-center justify-center transition-all ${isVoiceActive ? 'bg-rose-600 animate-pulse text-white' : 'bg-slate-800 text-slate-400 hover:text-white hover:bg-slate-700'}`}
              title={isVoiceActive ? "Stop Voice Mode" : "Start Voice Mode"}
            >
              <i className={`fas ${isVoiceActive ? 'fa-microphone-slash' : 'fa-microphone'}`}></i>
            </button>
          )}
          <div className="hidden sm:flex items-center space-x-2 px-3 py-1.5 bg-slate-950/50 rounded-full border border-slate-800">
            <div className={`w-2 h-2 rounded-full ${activeTab === 'ai' ? 'bg-indigo-500 animate-pulse' : 'bg-emerald-500 animate-pulse'}`}></div>
            <span className="text-[10px] text-slate-500 font-black uppercase tracking-widest">
              {activeTab === 'ai' ? 'Neural Link Active' : `${friends.length} Peers Online`}
            </span>
          </div>
        </div>
      </div>

      <div ref={scrollRef} className="flex-1 overflow-y-auto p-6 space-y-6 scroll-smooth scrollbar-hide">
        {isVoiceActive && (
          <div className="flex flex-col items-center justify-center h-full animate-in zoom-in duration-500">
            <div className="relative mb-8">
              <div className="w-32 h-32 bg-indigo-600/10 rounded-full flex items-center justify-center animate-pulse">
                <div className="w-24 h-24 bg-indigo-600/20 rounded-full flex items-center justify-center">
                  <div className="w-16 h-16 bg-indigo-600/40 rounded-full flex items-center justify-center">
                    <i className="fas fa-brain text-indigo-400 text-3xl"></i>
                  </div>
                </div>
              </div>
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="w-40 h-40 border-2 border-dashed border-indigo-500/20 rounded-full animate-[spin_10s_linear_infinite]"></div>
              </div>
            </div>
            <h2 className="text-xl font-black text-white uppercase tracking-widest mb-2">Voice Sync Active</h2>
            <p className="text-slate-500 text-[10px] font-bold uppercase tracking-[0.3em]">AI is listening to your commands</p>
            <div className="mt-12 flex space-x-1 items-end h-8">
               {[...Array(8)].map((_, i) => (
                 <div key={i} className="w-1.5 bg-indigo-500 rounded-full animate-wave" style={{ animationDelay: `${i * 0.1}s`, height: `${20 + Math.random() * 60}%` }}></div>
               ))}
            </div>
            <button onClick={stopVoiceMode} className="mt-12 px-8 py-3 bg-rose-600 hover:bg-rose-500 text-white font-black uppercase text-[10px] tracking-widest rounded-2xl transition-all shadow-xl shadow-rose-600/20">Disconnect Link</button>
          </div>
        )}

        {!isVoiceActive && messages.length === 0 && (
          <div className="h-full flex flex-col items-center justify-center text-center px-10 opacity-80">
            <div className={`w-20 h-20 rounded-[32px] flex items-center justify-center mb-6 shadow-2xl ${activeTab === 'ai' ? 'bg-indigo-600/20 text-indigo-400 border border-indigo-500/10' : 'bg-emerald-600/20 text-emerald-400 border border-emerald-500/10'}`}>
              <i className={`fas ${activeTab === 'ai' ? 'fa-robot' : 'fa-users-viewfinder'} text-4xl`}></i>
            </div>
            <h3 className="text-2xl font-black text-white mb-2 uppercase tracking-tighter">
              {activeTab === 'ai' ? 'Spend Smart Intelligence' : 'Community Protocol'}
            </h3>
            <p className="text-slate-500 text-xs font-medium max-w-xs leading-relaxed">
              {activeTab === 'ai' 
                ? "Deploy advanced financial reasoning or launch Voice Mode for real-time auditory advice."
                : friends.length > 0 
                  ? `Synced with ${friends.length} network entities. Community reports are aggregated below.`
                  : "Community node isolated. Expand your peer network to access group intelligence."}
            </p>
          </div>
        )}

        {!isVoiceActive && messages.map((m) => (
          <div key={m.id} className={`flex ${m.sender === 'user' ? 'justify-end' : 'justify-start'} animate-in slide-in-from-bottom-2 duration-300`}>
            <div className={`max-w-[85%] sm:max-w-[70%] rounded-[28px] p-5 shadow-xl ${
              m.sender === 'user' 
                ? 'bg-gradient-to-br from-indigo-600 to-indigo-700 text-white rounded-tr-none' 
                : 'bg-slate-800/80 backdrop-blur-md text-slate-100 rounded-tl-none border border-slate-700/50'
            }`}>
              {(m.sender === 'community' && m.name) && (
                <div className="flex items-center space-x-2 mb-2">
                   <div className="w-1 h-3 bg-emerald-500 rounded-full"></div>
                   <p className="text-[10px] font-black text-emerald-400 uppercase tracking-widest">{m.name}</p>
                </div>
              )}
              <p className="text-sm leading-relaxed font-medium">{m.text}</p>
              <div className={`flex items-center justify-end space-x-2 mt-3 opacity-40 ${m.sender === 'user' ? 'text-white' : 'text-slate-500'}`}>
                <i className={`fas ${m.sender === 'user' ? 'fa-check-double' : 'fa-microchip'} text-[8px]`}></i>
                <p className="text-[9px] uppercase font-black tracking-widest">{m.timestamp}</p>
              </div>
            </div>
          </div>
        ))}
        {isTyping && (
          <div className="flex justify-start animate-pulse">
            <div className="bg-slate-800/50 rounded-2xl p-4 rounded-tl-none flex space-x-1.5 border border-slate-700/50">
              <div className="w-1.5 h-1.5 bg-indigo-400 rounded-full animate-bounce"></div>
              <div className="w-1.5 h-1.5 bg-indigo-400 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
              <div className="w-1.5 h-1.5 bg-indigo-400 rounded-full animate-bounce" style={{ animationDelay: '0.4s' }}></div>
            </div>
          </div>
        )}
      </div>

      {!isVoiceActive && (
        <div className="p-6 bg-slate-900/40 backdrop-blur-xl border-t border-slate-800">
          <div className="flex items-center space-x-3 max-w-4xl mx-auto">
            <div className="flex-1 relative group">
              <div className="absolute inset-y-0 left-5 flex items-center text-slate-500 group-focus-within:text-indigo-400 transition-colors">
                <i className="fas fa-terminal text-xs"></i>
              </div>
              <input 
                type="text" 
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleSend()}
                placeholder={activeTab === 'ai' ? "Initialize AI prompt..." : "Broadcast to community node..."}
                className="w-full bg-slate-950 border border-slate-800 rounded-2xl pl-12 pr-12 py-4 text-white text-sm focus:outline-none focus:ring-1 focus:ring-indigo-500/50 transition-all placeholder-slate-700 shadow-inner"
              />
              <button className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-700 hover:text-white transition-colors">
                <i className="fas fa-paperclip text-sm"></i>
              </button>
            </div>
            <button 
              onClick={handleSend}
              disabled={!input.trim()}
              className="w-14 h-14 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-30 disabled:bg-slate-800 rounded-2xl flex items-center justify-center text-white transition-all shadow-xl shadow-indigo-600/30 active:scale-95 group"
            >
              <i className="fas fa-paper-plane group-hover:translate-x-1 group-hover:-translate-y-1 transition-transform"></i>
            </button>
          </div>
          <div className="mt-3 flex items-center justify-center space-x-4 opacity-40">
             <p className="text-[8px] font-black text-slate-600 uppercase tracking-[0.4em]">End-to-End Quantum Encryption Active</p>
          </div>
        </div>
      )}
      
      <style>{`
        @keyframes wave {
          0%, 100% { transform: scaleY(0.5); }
          50% { transform: scaleY(1.5); }
        }
        .animate-wave {
          animation: wave 1s ease-in-out infinite;
          transform-origin: bottom;
        }
      `}</style>
    </div>
  );
};

export default Chat;