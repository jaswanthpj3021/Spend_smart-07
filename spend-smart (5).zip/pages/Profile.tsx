import React, { useState, useRef } from 'react';
import { User, Theme, CustomTheme } from '../types';

interface ProfileProps {
  user: User;
  onLogout: () => void;
  onUpdateUser: (user: User) => void;
  theme: Theme;
  setTheme: (theme: Theme) => void;
  customThemes: CustomTheme[];
  setCustomThemes: React.Dispatch<React.SetStateAction<CustomTheme[]>>;
  activeCustomThemeId: string | null;
  setActiveCustomThemeId: (id: string | null) => void;
}

const Profile: React.FC<ProfileProps> = ({ 
  user, 
  onLogout, 
  onUpdateUser, 
  theme, 
  setTheme,
  customThemes,
  setCustomThemes,
  activeCustomThemeId,
  setActiveCustomThemeId
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isEditingName, setIsEditingName] = useState(false);
  const [editNameValue, setEditNameValue] = useState(user.name);
  const [copyStatus, setCopyStatus] = useState('Copy');
  
  const [showPasswordChange, setShowPasswordChange] = useState(false);
  const [passwordForm, setPasswordForm] = useState({ current: '', new: '', confirm: '' });

  const handleCopyPjId = () => {
    navigator.clipboard.writeText(user.pjId);
    setCopyStatus('Copied!');
    setTimeout(() => setCopyStatus('Copy'), 2000);
  };

  const handleAvatarChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        const base64 = reader.result as string;
        onUpdateUser({ ...user, avatar: base64 });
      };
      reader.readAsDataURL(file);
    }
  };

  const handleNameSave = () => {
    if (editNameValue.trim()) {
      onUpdateUser({ ...user, name: editNameValue });
      setIsEditingName(false);
    }
  };

  const handlePasswordUpdate = (e: React.FormEvent) => {
    e.preventDefault();
    if (passwordForm.new !== passwordForm.confirm) {
      alert("New passwords do not match!");
      return;
    }
    alert("Vault Access Key updated successfully.");
    setShowPasswordChange(false);
    setPasswordForm({ current: '', new: '', confirm: '' });
  };

  const themeOptions = [
    { id: Theme.DARK, name: 'Midnight', icon: 'fa-moon', color: 'bg-slate-900' },
    { id: Theme.LIGHT, name: 'Pure', icon: 'fa-sun', color: 'bg-white' },
    { id: Theme.NEON, name: 'Vapor', icon: 'fa-bolt-lightning', color: 'bg-indigo-950' },
    { id: Theme.CYBERPUNK, name: 'Grid', icon: 'fa-robot', color: 'bg-black' },
    { id: Theme.LUXURY, name: 'Gold', icon: 'fa-gem', color: 'bg-[#0a0a0a]' },
    { id: Theme.ATLANTIS, name: 'Ocean', icon: 'fa-water', color: 'bg-[#002b36]' },
    { id: Theme.MARS, name: 'Magma', icon: 'fa-fire', color: 'bg-[#1a0505]' },
    { id: Theme.LAVENDER, name: 'Silk', icon: 'fa-wand-sparkles', color: 'bg-[#120a1a]' },
  ];

  const getAccentColor = (currentTheme: Theme) => {
    if (currentTheme === Theme.CUSTOM) return 'text-[var(--accent-color)]';
    switch (currentTheme) {
      case Theme.LUXURY: return 'text-[#d4af37]';
      case Theme.ATLANTIS: return 'text-[#2aa198]';
      case Theme.MARS: return 'text-[#ff4d4d]';
      case Theme.LAVENDER: return 'text-[#e0b0ff]';
      default: return 'text-emerald-400';
    }
  };

  return (
    <div className="max-w-3xl mx-auto py-6 px-4 pb-32 space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-700">
      <div className="flex flex-col items-center justify-center space-y-6 text-center">
        <div className="relative group">
          <div className="w-32 h-32 sm:w-40 sm:h-40 rounded-[40px] border-4 border-emerald-500/20 p-1.5 shadow-2xl overflow-hidden bg-slate-900 relative">
            <div className="absolute inset-0 bg-gradient-to-tr from-emerald-600/10 to-transparent pointer-events-none"></div>
            {user.avatar ? (
              <img src={user.avatar} alt="Profile" className="w-full h-full object-cover rounded-[34px] group-hover:scale-110 transition-transform duration-500" />
            ) : (
              <div className="w-full h-full bg-emerald-600 flex items-center justify-center rounded-[34px]">
                <i className="fas fa-user-shield text-white text-5xl"></i>
              </div>
            )}
          </div>
          <input type="file" ref={fileInputRef} className="hidden" accept="image/*" onChange={handleAvatarChange} />
          <button 
            onClick={() => fileInputRef.current?.click()}
            className="absolute -bottom-2 -right-2 bg-emerald-600 w-12 h-12 rounded-2xl border-4 border-slate-950 flex items-center justify-center text-white hover:bg-teal-500 transition-all shadow-xl active:scale-90"
          >
            <i className="fas fa-camera text-sm"></i>
          </button>
        </div>
        
        <div className="space-y-2">
          {isEditingName ? (
            <div className="flex items-center space-x-2 bg-slate-900 border border-slate-800 rounded-2xl p-2 animate-in slide-in-from-top-2">
              <input 
                type="text"
                value={editNameValue}
                onChange={(e) => setEditNameValue(e.target.value)}
                autoFocus
                className="bg-transparent text-white px-4 py-1.5 font-black uppercase text-2xl focus:outline-none"
              />
              <button 
                onClick={handleNameSave}
                className="bg-emerald-600 w-10 h-10 rounded-xl flex items-center justify-center text-white text-sm hover:bg-emerald-500 shadow-lg shadow-emerald-500/20"
              >
                <i className="fas fa-check"></i>
              </button>
            </div>
          ) : (
            <div className="flex items-center justify-center space-x-4 group">
              <h1 className="text-3xl sm:text-5xl font-black text-inherit tracking-tighter uppercase italic">{user.name}</h1>
              <button 
                onClick={() => setIsEditingName(true)}
                className="sm:opacity-0 sm:group-hover:opacity-100 w-10 h-10 rounded-xl bg-slate-800 text-slate-400 hover:text-white transition-all flex items-center justify-center shadow-lg"
              >
                <i className="fas fa-pencil-alt text-xs"></i>
              </button>
            </div>
          )}
          <div className="flex items-center justify-center space-x-2 text-slate-500">
             <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></div>
             <p className="font-black uppercase text-[10px] tracking-[0.3em]">Clearance Level: Tier 1 Administrator</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="glass p-6 rounded-[36px] border border-emerald-500/10 shadow-xl bg-gradient-to-br from-emerald-600/5 to-transparent flex flex-col justify-between">
           <div>
              <p className="text-[10px] font-black text-emerald-500 uppercase tracking-[0.3em] mb-4">Sovereign Asset Key</p>
              <h2 className="text-3xl font-black text-white tracking-tighter uppercase mb-2">{user.pjId || 'PJ-0000000'}</h2>
              <p className="text-[9px] font-bold text-slate-500 uppercase tracking-widest leading-relaxed">Your unique peer-to-peer identifier for network synchronization and social auditing.</p>
           </div>
           <button 
             onClick={handleCopyPjId}
             className="mt-8 w-full py-4 bg-emerald-600 hover:bg-emerald-500 text-white rounded-2xl text-[11px] font-black uppercase tracking-widest transition-all shadow-xl shadow-emerald-500/20 active:scale-95 flex items-center justify-center space-x-3"
           >
             <i className={copyStatus === 'Copy' ? 'fas fa-copy' : 'fas fa-check-double'}></i>
             <span>{copyStatus} Asset Key</span>
           </button>
        </div>

        <div className="glass p-6 rounded-[36px] border border-slate-800 shadow-xl bg-slate-900/20 flex flex-col">
           <div className="flex items-center justify-between mb-6">
              <h3 className="text-[10px] font-black text-slate-500 uppercase tracking-[0.3em] flex items-center">
                <i className="fas fa-shield-halved mr-3 text-indigo-500"></i>
                Vault Protocol
              </h3>
              <div className="flex items-center space-x-1">
                 <div className="w-1.5 h-1.5 rounded-full bg-emerald-500"></div>
                 <span className="text-[8px] font-black text-emerald-500 uppercase tracking-widest">Encrypted</span>
              </div>
           </div>
           
           {showPasswordChange ? (
             <form onSubmit={handlePasswordUpdate} className="space-y-4 animate-in slide-in-from-top-2">
               <input 
                 type="password"
                 placeholder="Current Secret Key"
                 required
                 value={passwordForm.current}
                 onChange={e => setPasswordForm({...passwordForm, current: e.target.value})}
                 className="w-full bg-slate-950 border border-slate-800 rounded-xl px-5 py-3 text-xs text-white focus:outline-none focus:ring-1 focus:ring-emerald-500 transition-all placeholder-slate-700"
               />
               <input 
                 type="password"
                 placeholder="New Security Key"
                 required
                 value={passwordForm.new}
                 onChange={e => setPasswordForm({...passwordForm, new: e.target.value})}
                 className="w-full bg-slate-950 border border-slate-800 rounded-xl px-5 py-3 text-xs text-white focus:outline-none focus:ring-1 focus:ring-emerald-500 transition-all placeholder-slate-700"
               />
               <div className="flex space-x-2">
                  <button type="submit" className="flex-1 bg-indigo-600 hover:bg-indigo-500 text-white py-3 rounded-xl text-[10px] font-black uppercase tracking-widest shadow-lg">Commit Change</button>
                  <button type="button" onClick={() => setShowPasswordChange(false)} className="px-4 py-3 bg-slate-800 text-slate-400 rounded-xl text-[10px] font-black uppercase">Cancel</button>
               </div>
             </form>
           ) : (
             <>
               <p className="text-[10px] text-slate-600 font-bold uppercase leading-relaxed mb-auto">
                 Account security is governed by high-entropy keys. Access to Spend Smart AI and Global Networks is limited to authenticated vault sessions.
               </p>
               <button 
                onClick={() => setShowPasswordChange(true)}
                className="mt-6 text-[10px] font-black uppercase text-indigo-400 hover:text-white transition-all w-fit flex items-center space-x-2"
               >
                 <i className="fas fa-lock-open text-[8px]"></i>
                 <span>Cycle Security Key</span>
               </button>
             </>
           )}
        </div>
      </div>

      <div className="glass p-6 sm:p-8 rounded-[40px] border border-slate-800 shadow-2xl">
        <h3 className="text-[10px] font-black text-slate-500 uppercase tracking-[0.3em] mb-8">Visual Terminal Skins</h3>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
          {themeOptions.map(opt => (
            <button 
              key={opt.id}
              onClick={() => setTheme(opt.id)}
              className={`flex flex-col items-center justify-center p-5 rounded-[28px] border-2 transition-all duration-300 relative overflow-hidden group ${
                theme === opt.id 
                  ? 'border-emerald-500 bg-emerald-600/10 shadow-[0_0_20px_rgba(16,185,129,0.1)]' 
                  : 'border-slate-800 bg-slate-900/40 hover:border-slate-600 hover:bg-slate-800/40'
              }`}
            >
              <div className={`w-10 h-10 rounded-2xl mb-3 flex items-center justify-center ${opt.color} border border-white/5 shadow-xl group-hover:scale-110 transition-transform`}>
                 <i className={`fas ${opt.icon} ${theme === opt.id ? getAccentColor(opt.id) : 'text-slate-500'} text-sm`}></i>
              </div>
              <span className={`text-[10px] font-black uppercase tracking-widest ${theme === opt.id ? getAccentColor(opt.id) : 'text-slate-500'}`}>
                {opt.name}
              </span>
              {theme === opt.id && <div className="absolute top-2 right-2 w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></div>}
            </button>
          ))}
        </div>
      </div>

      <div className="flex flex-col items-center space-y-12">
        <button 
          onClick={onLogout}
          className="w-full max-w-sm py-5 bg-rose-600/10 text-rose-500 border border-rose-500/20 hover:bg-rose-600 hover:text-white rounded-[28px] font-black uppercase tracking-[0.4em] text-[11px] transition-all shadow-xl active:scale-95 flex items-center justify-center space-x-4 group"
        >
          <i className="fas fa-power-off group-hover:rotate-90 transition-transform duration-500"></i>
          <span>Lock Wealth Vault</span>
        </button>

        <div className="flex flex-col items-center justify-center space-y-4 opacity-70">
           <div className="flex items-center space-x-6 bg-slate-900/60 px-8 py-4 rounded-[30px] border border-slate-800 backdrop-blur-md shadow-lg">
             <span className="text-[11px] font-black uppercase tracking-[0.5em] text-slate-300">Proudly Made in India</span>
             <span className="text-3xl animate-bounce">🇮🇳</span>
           </div>
           <div className="flex flex-col items-center space-y-1">
             <p className="text-[9px] font-black text-slate-600 uppercase tracking-[0.6em]">Spend Smart Intelligence Core</p>
             <p className="text-[8px] font-bold text-emerald-500/40 uppercase tracking-[0.2em]">Build v3.8.0.R1 • All Rights Reserved</p>
           </div>
        </div>
      </div>
    </div>
  );
};

export default Profile;