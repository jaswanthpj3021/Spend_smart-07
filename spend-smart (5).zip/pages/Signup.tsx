import React, { useState } from 'react';
import { User } from '../types';

interface SignupProps {
  onSignup: (user: User) => void;
  onSwitch: () => void;
}

const Signup: React.FC<SignupProps> = ({ onSignup, onSwitch }) => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const generatePjId = () => {
    const digits = Math.floor(1000000 + Math.random() * 9000000);
    return `PJ-${digits}`;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSignup({
      id: Math.random().toString(36).substr(2, 9),
      pjId: generatePjId(),
      name,
      email,
      currency: 'INR',
      totalBudget: 0,
      memberSince: new Date().toISOString(),
      settings: {
        friendRequestNotifications: true
      }
    });
  };

  return (
    <div className="min-h-screen bg-slate-950 flex items-center justify-center p-4 relative overflow-hidden">
      <div className="absolute top-0 left-0 w-full h-full opacity-10 pointer-events-none">
        <div className="absolute top-20 right-20 w-80 h-80 bg-teal-600 rounded-full blur-[120px] animate-pulse"></div>
        <div className="absolute bottom-20 left-20 w-72 h-72 bg-blue-600 rounded-full blur-[130px]"></div>
      </div>

      <div className="w-full max-w-md glass p-10 rounded-[40px] shadow-2xl z-10 border border-slate-800 backdrop-blur-3xl">
        <div className="text-center mb-10">
          <div className="w-16 h-16 bg-teal-500 rounded-2xl flex items-center justify-center mx-auto mb-6 shadow-xl shadow-teal-500/20">
            <i className="fas fa-user-plus text-white text-2xl"></i>
          </div>
          <h1 className="text-4xl font-black text-white tracking-tighter mb-2 uppercase italic">Join Spend Smart</h1>
          <p className="text-slate-500 font-medium uppercase text-[10px] tracking-[0.2em]">Secure your financial future</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-5">
          <div>
            <div className="relative">
              <i className="fas fa-user absolute left-5 top-1/2 -translate-y-1/2 text-slate-600"></i>
              <input 
                type="text" 
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full bg-slate-900/80 border border-slate-800 rounded-2xl py-4 pl-14 pr-6 text-white placeholder-slate-600 focus:outline-none focus:ring-1 focus:ring-teal-500/50 transition-all font-medium"
                placeholder="Full Name"
              />
            </div>
          </div>

          <div>
            <div className="relative">
              <i className="fas fa-at absolute left-5 top-1/2 -translate-y-1/2 text-slate-600"></i>
              <input 
                type="email" 
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full bg-slate-900/80 border border-slate-800 rounded-2xl py-4 pl-14 pr-6 text-white placeholder-slate-600 focus:outline-none focus:ring-1 focus:ring-teal-500/50 transition-all font-medium"
                placeholder="Email Address"
              />
            </div>
          </div>

          <div>
            <div className="relative">
              <i className="fas fa-fingerprint absolute left-5 top-1/2 -translate-y-1/2 text-slate-600"></i>
              <input 
                type="password" 
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full bg-slate-900/80 border border-slate-800 rounded-2xl py-4 pl-14 pr-6 text-white placeholder-slate-600 focus:outline-none focus:ring-1 focus:ring-teal-500/50 transition-all font-medium"
                placeholder="Create Password"
              />
            </div>
          </div>

          <button 
            type="submit"
            className="w-full bg-teal-500 hover:bg-teal-400 text-white font-black uppercase tracking-widest py-5 rounded-2xl shadow-xl shadow-teal-500/20 transform transition-all active:scale-95 mt-4"
          >
            Join the Network
          </button>
        </form>

        <div className="mt-8 text-center">
          <p className="text-slate-500 text-sm font-medium">
            Already a member? 
            <button onClick={onSwitch} className="ml-2 text-teal-400 font-bold hover:underline">Sign In</button>
          </p>
        </div>
      </div>
    </div>
  );
};

export default Signup;