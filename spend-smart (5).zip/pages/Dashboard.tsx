import React, { useState, useEffect } from 'react';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip, Legend } from 'recharts';
import { User, Transaction, Category } from '../types';

const SUGGESTED_CATEGORIES = ['Food', 'Transport', 'Shopping', 'Rent', 'Entertainment', 'Education', 'Health', 'Subscription', 'Other'];

const Dashboard: React.FC<{ user: User, setView: (v: any) => void }> = ({ user, setView }) => {
  const [transactions, setTransactions] = useState<Transaction[]>(() => {
    const saved = localStorage.getItem('smartspend_transactions');
    return saved ? JSON.parse(saved) : [];
  });

  const [quickAdd, setQuickAdd] = useState({ amount: '', description: '', category: 'Food' });
  const [showCustomCategory, setShowCustomCategory] = useState(false);

  const handleQuickAdd = (e: React.FormEvent) => {
    e.preventDefault();
    if (!quickAdd.amount || !quickAdd.description) return;
    
    const tx: Transaction = {
      id: Math.random().toString(36).substr(2, 9),
      userId: user.id,
      amount: parseFloat(quickAdd.amount),
      description: quickAdd.description,
      category: quickAdd.category,
      type: 'expense',
      date: new Date().toISOString().split('T')[0]
    };
    
    const updated = [tx, ...transactions];
    setTransactions(updated);
    localStorage.setItem('smartspend_transactions', JSON.stringify(updated));
    setQuickAdd({ amount: '', description: '', category: 'Food' });
    setShowCustomCategory(false);
  };

  const totalSpent = transactions.reduce((sum, t) => sum + (t.type === 'expense' ? t.amount : 0), 0);
  const remaining = user.totalBudget - totalSpent;

  const handleShareStatus = async () => {
    const shareText = `📊 My Spend Smart Summary\n\n💰 Total Capital: ₹${user.totalBudget.toLocaleString()}\n📉 Burn Rate: ₹${totalSpent.toLocaleString()}\n🏦 Net Reserves: ₹${remaining.toLocaleString()}\n\nTrack your wealth with Spend Smart!`;
    
    if (navigator.share) {
      try {
        const shareData: ShareData = {
          title: 'Spend Smart Summary',
          text: shareText,
        };

        if (window.location.protocol.startsWith('http')) {
          shareData.url = window.location.href;
        }

        await navigator.share(shareData);
      } catch (err) {
        console.error('Error sharing:', err);
        navigator.clipboard.writeText(shareText);
        alert('Summary copied to clipboard!');
      }
    } else {
      navigator.clipboard.writeText(shareText);
      alert('Summary copied to clipboard!');
    }
  };

  const categoryData = Object.entries(
    transactions.reduce((acc: any, t) => {
      if (t.type === 'expense') {
        acc[t.category] = (acc[t.category] || 0) + t.amount;
      }
      return acc;
    }, {})
  ).map(([name, value]) => ({ name, value }));

  const COLORS = ['#10b981', '#059669', '#047857', '#065f46', '#064e3b', '#34d399', '#6ee7b7', '#a7f3d0'];

  return (
    <div className="space-y-6 pb-24">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-black text-white tracking-tighter uppercase">Think twice, spend once</h1>
          <p className="text-slate-500 text-[10px] font-black uppercase tracking-widest">Sovereign Wealth Controls</p>
        </div>
        <div className="flex items-center space-x-2">
          <button 
            onClick={handleShareStatus}
            className="flex-1 sm:flex-none flex items-center justify-center space-x-2 bg-slate-800 hover:bg-slate-700 text-emerald-400 px-4 py-3 rounded-2xl border border-slate-700 transition-all active:scale-95 shadow-lg"
          >
            <i className="fas fa-share-nodes text-xs"></i>
            <span className="text-[10px] font-black uppercase tracking-widest">Transmit</span>
          </button>
          <div className="hidden sm:flex items-center space-x-2 bg-emerald-600/10 px-4 py-3 rounded-2xl border border-emerald-500/20 w-fit">
            <i className="fas fa-tower-broadcast text-emerald-400 text-xs"></i>
            <span className="text-emerald-400 text-xs font-black uppercase tracking-widest">Live Sync</span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="glass p-6 rounded-3xl border-l-4 border-emerald-500 shadow-xl">
          <div className="flex items-center justify-between mb-2">
            <span className="text-slate-500 text-[10px] font-black uppercase tracking-[0.2em]">Primary Capital</span>
            <i className="fas fa-vault text-emerald-400 text-sm"></i>
          </div>
          <p className="text-2xl sm:text-3xl font-black text-white">₹{user.totalBudget.toLocaleString()}</p>
        </div>
        <div className="glass p-6 rounded-3xl border-l-4 border-rose-500 shadow-xl">
          <div className="flex items-center justify-between mb-2">
            <span className="text-slate-500 text-[10px] font-black uppercase tracking-[0.2em]">Active Outflow</span>
            <i className="fas fa-fire-flame-curved text-rose-400 text-sm"></i>
          </div>
          <p className="text-2xl sm:text-3xl font-black text-white">₹{totalSpent.toLocaleString()}</p>
        </div>
        <div className="glass p-6 rounded-3xl border-l-4 border-sky-500 shadow-xl">
          <div className="flex items-center justify-between mb-2">
            <span className="text-slate-500 text-[10px] font-black uppercase tracking-[0.2em]">Net Reserves</span>
            <i className="fas fa-microchip text-sky-400 text-sm"></i>
          </div>
          <p className="text-2xl sm:text-3xl font-black text-white">₹{remaining.toLocaleString()}</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div className="lg:col-span-5 glass p-6 rounded-[32px] border border-emerald-500/10 flex flex-col">
          <h3 className="text-lg font-black text-white mb-6 flex items-center tracking-tighter uppercase">
            <div className="w-8 h-8 bg-emerald-600/20 rounded-lg flex items-center justify-center mr-3">
               <i className="fas fa-plus text-emerald-400 text-xs"></i>
            </div>
            Quick Entry
          </h3>
          <form onSubmit={handleQuickAdd} className="space-y-4">
            <div>
              <label className="block text-slate-500 text-[10px] font-black uppercase tracking-widest mb-1">Description</label>
              <input 
                type="text" 
                required
                value={quickAdd.description}
                onChange={(e) => setQuickAdd({ ...quickAdd, description: e.target.value })}
                className="w-full bg-slate-900/50 border border-slate-800 rounded-2xl px-5 py-4 text-white text-sm focus:ring-2 focus:ring-emerald-500/50 outline-none transition-all placeholder-slate-600"
                placeholder="Ex: Grocery Sync"
              />
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-slate-500 text-[10px] font-black uppercase tracking-widest mb-1">Amount (₹)</label>
                <input 
                  type="number" 
                  required
                  value={quickAdd.amount}
                  onChange={(e) => setQuickAdd({ ...quickAdd, amount: e.target.value })}
                  className="w-full bg-slate-900/50 border border-slate-800 rounded-2xl px-5 py-4 text-white text-sm font-bold focus:ring-2 focus:ring-emerald-500/50 outline-none transition-all"
                  placeholder="0.00"
                />
              </div>
              <div>
                <label className="block text-slate-500 text-[10px] font-black uppercase tracking-widest mb-1">Category</label>
                {!showCustomCategory ? (
                  <select 
                    value={quickAdd.category}
                    onChange={(e) => {
                      if (e.target.value === 'CUSTOM') {
                        setShowCustomCategory(true);
                        setQuickAdd({ ...quickAdd, category: '' });
                      } else {
                        setQuickAdd({ ...quickAdd, category: e.target.value });
                      }
                    }}
                    className="w-full bg-slate-900/50 border border-slate-800 rounded-2xl px-5 py-4 text-white text-sm focus:ring-2 focus:ring-emerald-500/50 outline-none transition-all"
                  >
                    {SUGGESTED_CATEGORIES.map(c => <option key={c} value={c}>{c}</option>)}
                    <option value="CUSTOM">+ New Category</option>
                  </select>
                ) : (
                  <div className="relative">
                    <input 
                      type="text" 
                      autoFocus
                      required
                      value={quickAdd.category}
                      onChange={(e) => setQuickAdd({ ...quickAdd, category: e.target.value })}
                      className="w-full bg-slate-900/50 border border-emerald-500/50 rounded-2xl px-5 py-4 text-white text-sm focus:ring-2 focus:ring-emerald-500/50 outline-none transition-all"
                      placeholder="Category Name"
                    />
                    <button 
                      type="button" 
                      onClick={() => { setShowCustomCategory(false); setQuickAdd({...quickAdd, category: 'Food'}); }}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-500 hover:text-white"
                    >
                      <i className="fas fa-times text-xs"></i>
                    </button>
                  </div>
                )}
              </div>
            </div>
            <button 
              type="submit"
              className="w-full bg-emerald-600 hover:bg-emerald-500 text-white font-black uppercase tracking-[0.2em] py-4 rounded-2xl transition-all shadow-xl shadow-emerald-500/20 text-xs active:scale-95"
            >
              Commit Entry
            </button>
          </form>
        </div>

        <div className="lg:col-span-7 glass p-6 rounded-[32px] flex flex-col min-h-[350px]">
          <h3 className="text-lg font-black text-white mb-4 tracking-tighter uppercase">Distribution</h3>
          <div className="flex-1 min-h-[250px]">
            {categoryData.length > 0 ? (
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={categoryData}
                    cx="50%"
                    cy="50%"
                    innerRadius={60}
                    outerRadius={80}
                    paddingAngle={5}
                    dataKey="value"
                  >
                    {categoryData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip 
                    contentStyle={{ backgroundColor: '#0f172a', border: '1px solid #334155', borderRadius: '16px', color: '#fff', fontSize: '12px', fontWeight: 'bold' }}
                    itemStyle={{ color: '#fff' }}
                    formatter={(value) => `₹${value.toLocaleString()}`}
                  />
                  <Legend verticalAlign="bottom" height={36} iconType="circle" wrapperStyle={{ fontSize: '9px', fontWeight: 'black', textTransform: 'uppercase', letterSpacing: '0.1em' }}/>
                </PieChart>
              </ResponsiveContainer>
            ) : (
              <div className="flex flex-col items-center justify-center h-full text-slate-600 italic">
                <i className="fas fa-wave-square text-5xl mb-4 opacity-5"></i>
                <p className="font-bold uppercase tracking-widest text-[10px]">Vault Records Empty</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;